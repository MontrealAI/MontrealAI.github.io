# Build Instructions

## Requirements

A current TeX Live distribution with `latexmk`, `pdflatex`, TikZ, tcolorbox, newtx, natbib, hyperref and the standard LaTeX packages used by `main.tex`.

## Definitive modular paper

```bash
cd source
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

## Single-file paper

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  GoalOS_SEIZE_The_Verified_Succession_Institution_SINGLE_FILE.tex
```

## Executive brief

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error executive_brief.tex
```

## Clean build

```bash
latexmk -C
```

The modular and single-file paper editions are expected to render identically.
