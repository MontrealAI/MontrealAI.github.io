---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## MONTRÉAL.AI SPACE

__We are living in a period of unprecedented breakthroughs in science.__ Near future advances at the intersection of __*aerospace engineering*__ and __*artificial intelligence*__ hold out extraordinary prospects for the future of Mankind.

[![Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created MONTREAL.AI SPACE. — Vincent Boucher, Founding Chairman at Montréal.AI](../images/vincentboucher1440.jpg "Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created MONTREAL.AI SPACE. — Vincent Boucher, Founding Chairman at Montréal.AI")](http://www.montreal.ai/vincentboucher.jpg)

__A Legendary History | How It All Began —__ Learn the source of an exceptional legacy :

- [Vincent Boucher | ... un cerveau de l'aérospatial!](http://www.montreal.ai/mtl.pdf) — Le journal de Montreal
- [Shooting Stars | Vincent Boucher](http://www.montreal.ai/csa.pdf) — The Canadian Space Agency Employee Newsletter
- [Vincent Boucher | Un (jeune) homme d'exception](http://www.montreal.ai/lapresse.pdf) — Nathalie Petrowski, La Presse

> "**_Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created Montréal.AI Space._**" — Vincent Boucher, Founding Chairman at Montréal.AI

## Montréal.AI Space | Vision

![Montréal.AI Space](../images/consultingspace1920v0.jpg "Montréal.AI Space")
{% pullquote [CSS class] %}
"**_If you have a large big dataset and you train a very big neural network, then success is guaranteed!_**" — Ilya Sutskever
{% endpullquote %}
__Our Vision :__ To be the keystone of the AI Space industry.

[![Our Vision : To be the keystone of the AI Space industry.](../images/montrealaispace1280x720.jpg "Our Vision : To be the keystone of the AI Space industry.")](http://www.montreal.ai/mtl.pdf)

AI Space research is the one most capable of responding to the fundamental paradigm shift underway.

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Executive Council and Administrative Head Office*

#__AIFirst__ #__MontrealAI__ #__MontrealAISpace__ #__MontrealArtificialIntelligence__
