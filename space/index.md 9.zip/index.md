---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## MONTRÉAL.AI SPACE

__A New Era of Superhuman Scientific Discoveries.__

[![Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created MONTREAL.AI SPACE. — Vincent Boucher, B. Sc. Theoretical Physics, M. A. Government Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI](../images/vincentboucher1440.jpg "Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created MONTREAL.AI SPACE. — Vincent Boucher, B. Sc. Theoretical Physics, M. A. Government Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI")](http://www.montreal.ai/vincentboucher.jpg)

__A Legendary History | How It All Began —__ Learn the source of an exceptional legacy :
<p align="center">
[![A Legendary History | How It All Began](../images/journalmontreal.jpg "A Legendary History | How It All Began")](http://www.montreal.ai/mtl.pdf)
</p>
- [Vincent Boucher | ... un cerveau de l'aérospatial!](http://www.montreal.ai/mtl.pdf) — Le journal de Montreal
- [Shooting Stars | Vincent Boucher](http://www.montreal.ai/csa.pdf) — The Canadian Space Agency Employee Newsletter
- [Vincent Boucher | Un (jeune) homme d'exception](http://www.montreal.ai/lapresse.pdf) — Nathalie Petrowski, La Presse

![Feynman Diagrams | Quantum Electrodynamics](../images/FeynmanDiagramsQuantumElectrodynamics-QED.png "Feynman Diagrams | Quantum Electrodynamics")

## Montréal.AI Space : Premium Vision

__AI + Aerospace | Physics | Robotics__

__Premium Vision :__ __*To be the keystone of the AI Space industry.*__

> "**_Recognizing that Montreal is a world-class aerospace industry hub and a world leader in artificial intelligence, we've created Montréal.AI Space._**" — Vincent Boucher, B. Sc. Physics, M. A. Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI

__Montréal.AI Space__ has a Jewel status in the __*Montréal.AI Portfolio*__.

![Montréal.AI Space : The Keystone of the AI Space Industry](../images/consultingspace1920v0.jpg "Montréal.AI Space : The Keystone of the AI Space Industry")

> "**_What I cannot create, I do not understand._**" — Richard Feynman

## Montréal.AI Space : Solving Humanity’s Toughest Challenges

__We are at the verge of a global technological shift.__

__Montréal.AI Space__ leverages *aerospace engineering*, *applied artificial intelligence* and  *space science* researches for use in __spaceflight__, __satellites__, and __space exploration__ on an unprecedented scale.

A new powerful model for a large number of emerging superintelligence giants spreading across a landscape.

![A Supermassive Black Hole | Image credit : NASA/JPL-Caltech](../images/montrealaispace_shifting_coronas_around_black_holes_1280x720.jpg "A Supermassive Black Hole | Image credit : NASA/JPL-Caltech")

> "**_Any Sufficiently Advanced Technology is Indistinguishable from Magic._**" — Arthur C. Clarke

## Montréal.AI Space : Exploring the Stars and the Universe

We are living in a period of unprecedented breakthroughs in science. Near future advances at the intersection of *aerospace engineering* and *artificial intelligence* hold out extraordinary prospects for the future of Mankind.

{% pullquote [CSS class] %}
"**_Artificial Intelligence is about recognising patterns, Artificial Life is about creating patterns._**" — Mizuki Oka et al, #alife2018
{% endpullquote %}

__Montréal.AI Space__ believes in enhancing Humanity’s well-being by leveraging superintelligence to explore the Stars : __*The place where we truly belong*__.

With higher ingenuity, we implements world‐class agents to design breakthrough deep learning algorithms with an understanding of our __Universe__.

[![Our Vision : To be the keystone of the AI Space industry.](../images/montrealaispaceneuralnetworks1920x1080.jpg "Our Vision : To be the keystone of the AI Space industry.")](http://www.montreal.ai/mtl.pdf)

> "**_I think transfer learning is the key to general intelligence. And I think the key to doing transfer learning will be the acquisition of conceptual knowledge that is abstracted away from perceptual details of where you learned it from._**" — Demis Hassabis

Montréal.AI’s superhuman AI agents can learn from experience, simulate worlds and orchestrate meta-solutions.

__Montréal.AI Space__ is offering a new world age of impactful technical prowesses on a truly global scale.

> "**_Of course, particle physicists are among the first to realize that nature is compositional._**" — Yann LeCun

### References

- [Why does deep and cheap learning work so well?](https://arxiv.org/abs/1608.08225) — Henry W. Lin, Max Tegmark, David Rolnick
- [Introduction to astroML: Machine Learning for Astrophysics](https://arxiv.org/pdf/1411.5039.pdf) — Jacob VanderPlas, Andrew J. Connolly, Zˇeljko Ivezic ́, Alex Gray
- [CosmoFlow: Using Deep Learning to Learn the Universe at Scale](https://arxiv.org/pdf/1808.04728.pdf) — Mathuriya et al.
- [Galaxy morphology prediction using capsule networks](https://arxiv.org/abs/1809.08377) — Katebi et al.
- [Machine Learning for Physics and the Physics of Learning](http://www.ipam.ucla.edu/programs/long-programs/machine-learning-for-physics-and-the-physics-of-learning/) — Steve Brunton, Cecilia Clementi, Yann LeCun, Marina Meila, Frank Noe, Francesco Paesani
- [MINERVA-II1: Successful image capture, landing on Ryugu and hop!](http://www.hayabusa2.jaxa.jp/en/topics/20180922e/) — JAXA | Japan Aerospace Exploration Agency
- [Restricted Boltzmann Machines for Collaborative Filtering](https://www.cs.toronto.edu/~rsalakhu/papers/rbmcf.pdf) — Ruslan Salakhutdinov, Andriy Mnih, Geoffrey Hinton
- [A Practical Guide to Training Restricted Boltzmann Machines](https://www.cs.toronto.edu/~hinton/absps/guideTR.pdf) — Geoffrey Hinton
- [GAIA DATA RELEASE 1](https://www.cosmos.esa.int/web/gaia/data-release-1) — European Space Agency
- [Evolved Virtual Creatures, Evolution Simulation, 1994](https://youtu.be/JBgG_VSP7f8) — Karl Sims
- [AI Model Could Help Robots Navigate on the Moon and Mars Without GPS](https://news.developer.nvidia.com/ai-model-could-help-robots-navigate-on-the-moon-and-mars-without-gps/) — NVIDIA
- Machine Learning and Likelihood-Free Inference in Particle Physics [Slides](https://figshare.com/articles/NIPS_2016_Keynote_Machine_Learning_Likelihood_Free_Inference_in_Particle_Physics/4291565/1) | [Video](https://channel9.msdn.com/Events/Neural-Information-Processing-Systems-Conference/Neural-Information-Processing-Systems-Conference-NIPS-2016/Machine-Learning-and-Likelihood-Free-Inference-in-Particle-Physics) — Kyle Cranmer
- [Enabling Dark Energy Science with Deep Generative Models of Galaxy Images](https://arxiv.org/abs/1609.05796) — Siamak Ravanbakhsh, Francois Lanusse, Rachel Mandelbaum, Jeff Schneider, Barnabas Poczos
- [Unity and DeepMind to Advance AI Research Using Virtual Worlds](https://www.businesswire.com/news/home/20180926005180/en/Unity-DeepMind-Advance-AI-Research-Virtual-Worlds) — Business Wire
- [A look at deep learning for science](https://www.oreilly.com/ideas/a-look-at-deep-learning-for-science) — Prabhat
- [Searching for Exotic Particles in High-Energy Physics with Deep Learning](https://arxiv.org/abs/1402.4735) — Pierre Baldi, Peter Sadowski, Daniel Whiteson
- [Estimating Cosmological Parameters from the Dark Matter Distribution](https://arxiv.org/abs/1711.02033) — Siamak Ravanbakhsh, Junier Oliva, Sebastien Fromenteau, Layne C. Price, Shirley Ho, Jeff Schneider, Barnabas Poczos

## "GET ON A ROCKET SHIP" : Join Montréal.AI Space!

Bringing contributions by scholars recognized as the foremost authorities in their fields, __Montréal.AI Space__ is ahead of a trend that will profoundly influence the future of Humanity.

[![Our Vision : To be the keystone of the AI Space industry.](../images/montrealaispace1280x720.jpg "Our Vision : To be the keystone of the AI Space industry.")](http://www.montreal.ai/mtl.pdf)

__Montréal.AI Space__ is looking for successful __*Associates*__ & __*Partners*__ : *Captains of Industries*, *Philanthropists*, *Iconic Tech Entrepreneurs*, *Financiers* and *World-Class Scholars* to join us in this task of historic proportions.

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Executive Council and Administrative Head Office*

#__AIFirst__ #__MontrealAI__ #__MontrealAISpace__ #__MontrealArtificialIntelligence__
