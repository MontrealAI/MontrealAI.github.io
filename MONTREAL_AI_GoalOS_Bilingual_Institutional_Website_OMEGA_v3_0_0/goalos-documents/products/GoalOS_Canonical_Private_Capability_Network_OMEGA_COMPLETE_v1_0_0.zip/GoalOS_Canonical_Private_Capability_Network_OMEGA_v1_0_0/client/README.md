# Invocation Client and Public Verifier

```bash
npm install
npm run verify
```

Configure `dist/config.js` only with public deployment values. No private capsule, key, system instruction, model route, customer-private data, or production secret belongs in static files.
