#!/usr/bin/env node
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const getArg = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? resolve(process.cwd(), args[i + 1]) : resolve(ROOT, fallback);
};
const gatewayPath = getArg('--gateway', 'gateway/wrangler.production.example.toml');
const executorPath = getArg('--executor', 'executor/wrangler.production.example.toml');
const clientConfigPath = getArg('--client-config', 'client/dist/config.js');
const operatorConfigPath = getArg('--operator-config', 'operator/dist/config.js');

const failures = [];
const notes = [];
function requireFile(path, label) {
  if (!existsSync(path)) { failures.push(`${label} missing: ${path}`); return ''; }
  return readFileSync(path, 'utf8');
}
function reject(text, pattern, message) { if (pattern.test(text)) failures.push(message); }
function requireMatch(text, pattern, message) { if (!pattern.test(text)) failures.push(message); }

const gateway = requireFile(gatewayPath, 'Gateway production config');
const executor = requireFile(executorPath, 'Executor production config');
const client = requireFile(clientConfigPath, 'Client production config');
const operator = requireFile(operatorConfigPath, 'Operator production config');

for (const [label, text] of [['gateway', gateway], ['executor', executor], ['client', client], ['operator', operator]]) {
  if (!text) continue;
  reject(text, /REPLACE|example\.invalid|CI_ONLY|DEMO_ONLY|NOT_A_PRODUCTION_SECRET/i, `${label}: placeholder or rehearsal value remains`);
  reject(text, /0x0{40}\b/i, `${label}: zero contract address remains`);
}

if (gateway) {
  requireMatch(gateway, /workers_dev\s*=\s*false/i, 'gateway: workers_dev must be false');
  requireMatch(gateway, /CHAIN_ID\s*=\s*["']1["']/i, 'gateway: Ethereum Mainnet chain ID must be 1');
  requireMatch(gateway, /AGENT_PARENT_NAME\s*=\s*["']agent\.agi\.eth["']/i, 'gateway: institutional root must be agent.agi.eth');
  requireMatch(gateway, /APPROVED_NAME_WRAPPERS\s*=\s*["']0x[0-9a-fA-F]{40}/i, 'gateway: at least one reviewed Name Wrapper must be configured');
  requireMatch(gateway, /ALLOWED_ORIGINS\s*=\s*["']https:\/\//i, 'gateway: HTTPS origin allowlist is required');
  requireMatch(gateway, /\[\[services\]\][\s\S]*binding\s*=\s*["']EXECUTOR["']/i, 'gateway: internal EXECUTOR service binding is required');
  requireMatch(gateway, /\[assets\][\s\S]*run_worker_first\s*=\s*(?:true|\[[^\]]+\])/i, 'gateway: protected requests must run through the Worker first');
  reject(gateway, /^\s*(RPC_URL|SESSION_HMAC_KEY)\s*=/im, 'gateway: RPC_URL and SESSION_HMAC_KEY must be secrets, not [vars]');
}

if (executor) {
  requireMatch(executor, /workers_dev\s*=\s*false/i, 'executor: workers_dev must be false');
  reject(executor, /routes\s*=|route\s*=/i, 'executor: public routes must not be configured');
  requireMatch(executor, /\[\[r2_buckets\]\][\s\S]*binding\s*=\s*["']PRIVATE_CAPSULES["']/i, 'executor: private capsule bucket is required');
  const hasStore = /\[\[secrets_store_secrets\]\][\s\S]*binding\s*=\s*["']CAPSULE_MASTER_KEY["']/i.test(executor);
  if (!hasStore) notes.push('executor: no Secrets Store binding detected; ensure CAPSULE_MASTER_KEY_B64 is set only as a Worker secret for rehearsal, never as a plaintext var');
  reject(executor, /^\s*CAPSULE_MASTER_KEY_B64\s*=/im, 'executor: capsule key must not be a plaintext [vars] value');
}

if (client) {
  requireMatch(client, /gatewayBase\s*:\s*["']https:\/\//i, 'client: HTTPS gatewayBase must be configured');
  requireMatch(client, /chainId\s*:\s*1\b/i, 'client: chainId must be Ethereum Mainnet');
  requireMatch(client, /entitlementRegistry\s*:\s*["']0x[0-9a-fA-F]{40}["']/i, 'client: entitlement registry address is required');
}

if (operator) {
  for (const field of ['candidateRegistry', 'chronicleRegistry', 'entitlementRegistry']) {
    requireMatch(operator, new RegExp(`${field}\\s*:\\s*["']0x[0-9a-fA-F]{40}["']`, 'i'), `operator: ${field} address is required`);
  }
  requireMatch(operator, /chainId\s*:\s*1\b/i, 'operator: chainId must be Ethereum Mainnet');
}

console.log('GoalOS production preflight');
for (const n of notes) console.log(`NOTE  ${n}`);
if (failures.length) {
  for (const f of failures) console.error(`FAIL  ${f}`);
  console.error(`\nPRE-FLIGHT FAILED: ${failures.length} blocking issue(s).`);
  process.exit(1);
}
console.log('PASS  production configuration contains no known placeholders and satisfies the static activation gates.');
console.log('BOUNDARY  This does not replace live Mainnet acceptance, smart-contract audit, cryptographic review, key-management review, penetration testing, or incident rehearsal.');
