#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, shutil, stat, tempfile, zipfile
from pathlib import Path, PurePosixPath

EXCLUDED_DIRS={"node_modules",".wrangler",".git","release","__pycache__"}
GENERATED={"FINAL_RELEASE_MANIFEST.json","SHA256SUMS.txt","PACKAGE_VERIFICATION.json"}
RELEASE_NAME="GoalOS_Canonical_Private_Capability_Network_OMEGA_COMPLETE_v1_0_0.zip"
TOP_LEVEL="GoalOS_Canonical_Private_Capability_Network_OMEGA_v1_0_0"
NORMALIZED_TIME=(2026,7,19,0,0,0)
RELEASE_TIMESTAMP="2026-07-19T19:00:00Z"

def sha(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def included(root:Path,p:Path)->bool:
    rel=p.relative_to(root)
    return p.is_file() and not any(part in EXCLUDED_DIRS for part in rel.parts)

def files(root:Path,exclude_generated=False):
    out=[]
    for p in root.rglob('*'):
        if not included(root,p):continue
        if exclude_generated and p.name in GENERATED and p.parent==root:continue
        out.append(p)
    return sorted(out,key=lambda p:p.relative_to(root).as_posix())

def release_root(entries):
    h=hashlib.sha256()
    for e in entries:h.update(f"{e['path']}\0{e['sha256']}\n".encode())
    return h.hexdigest()

def write_manifests(root:Path):
    for n in GENERATED:
        p=root/n
        if p.exists():p.unlink()
    base=files(root,exclude_generated=True)
    qa_path=root/'qa/FINAL_VERIFICATION_REPORT.json'
    qa=json.loads(qa_path.read_text()) if qa_path.exists() else {}
    verification={
      "schema":"goalos.packageVerification.v1","release":"GoalOS Canonical Private Capability Network OMEGA v1.0.0",
      "generatedAt":RELEASE_TIMESTAMP,"status":"PASS" if qa.get('status')=='PASS' else "REVIEW",
      "sourceFileCount":len(base),"excludedDirectories":sorted(EXCLUDED_DIRS),"symlinkCount":sum(1 for p in root.rglob('*') if p.is_symlink()),
      "finalVerificationStatus":qa.get('status','UNKNOWN'),"productionActivated":False,
      "boundary":"Package integrity does not replace live Mainnet acceptance, independent audit, production key ceremony, penetration testing, or incident rehearsal."
    }
    (root/'PACKAGE_VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
    manifest_files=files(root,exclude_generated=True)+[root/'PACKAGE_VERIFICATION.json']
    manifest_entries=[{"path":p.relative_to(root).as_posix(),"size":p.stat().st_size,"sha256":sha(p)} for p in sorted(set(manifest_files),key=lambda p:p.relative_to(root).as_posix())]
    manifest={"schema":"goalos.releaseManifest.v1","release":"GoalOS Canonical Private Capability Network OMEGA v1.0.0","version":"1.0.0","generatedAt":RELEASE_TIMESTAMP,"topLevelDirectory":TOP_LEVEL,"fileCount":len(manifest_entries),"releaseRoot":release_root(manifest_entries),"files":manifest_entries,"claimBoundary":{"liveMainnetAcceptance":False,"independentAudit":False,"productionActivated":False}}
    (root/'FINAL_RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    checksum_files=[p for p in files(root) if not (p.parent==root and p.name=='SHA256SUMS.txt')]
    lines=[f"{sha(p)}  {p.relative_to(root).as_posix()}" for p in checksum_files]
    (root/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
    return manifest

def make_zip(root:Path,out_dir:Path):
    out_dir.mkdir(parents=True,exist_ok=True)
    archive=out_dir/RELEASE_NAME
    if archive.exists():archive.unlink()
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,strict_timestamps=True) as z:
        for p in files(root):
            rel=PurePosixPath(TOP_LEVEL)/PurePosixPath(p.relative_to(root).as_posix())
            info=zipfile.ZipInfo(str(rel),NORMALIZED_TIME)
            info.compress_type=zipfile.ZIP_DEFLATED
            info.create_system=3
            mode=0o755 if os.access(p,os.X_OK) or p.suffix in {'.sh'} else 0o644
            info.external_attr=(stat.S_IFREG|mode)<<16
            info.flag_bits|=0x800
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return archive

def verify(root:Path,archive:Path):
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(f"Corrupt archive member: {bad}")
        names=z.namelist()
        if len(names)!=len(set(names)):raise RuntimeError("Duplicate archive entries")
        if any(Path(n).is_absolute() or '..' in PurePosixPath(n).parts for n in names):raise RuntimeError("Unsafe archive path")
        with tempfile.TemporaryDirectory() as td:
            z.extractall(td)
            extracted=Path(td)/TOP_LEVEL
            for line in (extracted/'SHA256SUMS.txt').read_text().splitlines():
                digest,rel=line.split('  ',1)
                p=extracted/rel
                if not p.exists() or sha(p)!=digest:raise RuntimeError(f"Checksum mismatch after extraction: {rel}")
    source=[p.relative_to(root).as_posix() for p in files(root)]
    with zipfile.ZipFile(archive) as z:
        archived=[str(PurePosixPath(n).relative_to(TOP_LEVEL)) for n in z.namelist()]
    if source!=archived:raise RuntimeError("Archive membership differs from source release set")
    return {"zipIntegrity":True,"safePaths":True,"uniqueEntries":True,"cleanExtractionChecksums":True,"memberCount":len(source)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');ap.add_argument('--out',default='release');args=ap.parse_args()
    root=Path(args.root).resolve();out=Path(args.out).resolve()
    manifest=write_manifests(root);archive=make_zip(root,out);checks=verify(root,archive)
    archive_hash=sha(archive)
    external={"schema":"goalos.downloadManifest.v1","archive":archive.name,"size":archive.stat().st_size,"sha256":archive_hash,"fileCount":checks['memberCount'],"releaseRoot":manifest['releaseRoot'],"verification":checks,"generatedAt":dt.datetime.now(dt.timezone.utc).isoformat()}
    (out/'DOWNLOAD_MANIFEST.json').write_text(json.dumps(external,indent=2)+'\n')
    (out/'DOWNLOAD_SHA256SUMS.txt').write_text(f"{archive_hash}  {archive.name}\n{sha(root/'FINAL_RELEASE_MANIFEST.json')}  FINAL_RELEASE_MANIFEST.json\n{sha(root/'SHA256SUMS.txt')}  SHA256SUMS.txt\n")
    print(json.dumps(external,indent=2))
if __name__=='__main__':main()
