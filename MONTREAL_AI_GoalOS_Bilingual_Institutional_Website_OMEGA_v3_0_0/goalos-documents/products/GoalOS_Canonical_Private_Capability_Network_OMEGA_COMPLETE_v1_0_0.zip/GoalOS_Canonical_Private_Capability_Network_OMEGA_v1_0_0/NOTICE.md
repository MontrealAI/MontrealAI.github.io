# Notice

GoalOS Canonical Private Capability Network Ω is an open reference implementation by MONTREAL.AI.

The open code and verification formats do not grant access to MONTREAL.AI private capability capsules, production infrastructure, signing keys, customer data, Chronicle authority, deployed entitlements, or the `agent.agi.eth` namespace.

This release is a deployment-ready release candidate, not an audited or activated Mainnet production system. Independent smart-contract, cryptographic, security, privacy, and operational review remains required before production activation.
