import type { Hex } from "viem";
export type Address=`0x${string}`;
export interface InvocationEnvelope { requestId:string; agentName:string; agentNode:Hex; wallet:Address; entitlementId:Hex; skillId:Hex; operation:number; scopeHash:Hex; graphRoot:Hex; policyHash:Hex; capsuleCommitment:Hex; handlerId:string; input:unknown; inputHash:Hex; issuedAt:number; }
export interface InvocationResult { status:"ok"|"blocked"; output?:unknown; outputHash:Hex; blockedReason?:string; evidence?:Record<string,unknown>; }
export interface OutputPolicy { allowedTopLevelKeys:string[]; protectedFieldNames:string[]; protectedFragments:string[]; maxBytes:number; maxDepth:number; maxArrayLength:number; maxStringLength:number; }
export interface PrivateCapabilityCapsule { schema:string; skillId:Hex; handlerId:string; scopeHash:Hex; policyHash:Hex; operations:number; modelRoute:"deterministic"|"private-model"; systemInstruction:string; toolAllowlist:string[]; outputPolicy:OutputPolicy; deterministicTemplate?:Record<string,unknown>; }
export interface EncryptedCapsuleEnvelope { schema:string; algorithm:"AES-256-GCM"; ivB64:string; ciphertextB64:string; aad:string; }
