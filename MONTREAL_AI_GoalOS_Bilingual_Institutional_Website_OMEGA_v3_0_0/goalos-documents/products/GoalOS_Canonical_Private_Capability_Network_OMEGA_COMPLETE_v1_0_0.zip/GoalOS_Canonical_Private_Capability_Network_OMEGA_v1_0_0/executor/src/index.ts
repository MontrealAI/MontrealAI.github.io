import { WorkerEntrypoint } from "cloudflare:workers";
import type { InvocationEnvelope, InvocationResult, EncryptedCapsuleEnvelope } from "./types";
import { commitment, decryptCapsule, executeDeterministic, sanitizeOutput, validateCapsule } from "./core";

interface PrivateModelBinding { fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>; }
interface SecretStoreBinding { get(): Promise<string>; }
interface Env {
  PRIVATE_CAPSULES: R2Bucket;
  CAPSULE_MASTER_KEY?: SecretStoreBinding;
  CAPSULE_MASTER_KEY_B64?: string;
  OUTPUT_MAX_BYTES: string;
  MAX_INVOCATION_AGE_SECONDS?: string;
  PRIVATE_MODEL_TIMEOUT_MS?: string;
  MODEL_RUNTIME?: PrivateModelBinding;
}

async function loadCapsuleKey(env: Env): Promise<string> {
  if (env.CAPSULE_MASTER_KEY) return await env.CAPSULE_MASTER_KEY.get();
  if (env.CAPSULE_MASTER_KEY_B64) return env.CAPSULE_MASTER_KEY_B64;
  throw new Error("No protected capsule-key binding is configured.");
}

export default class GoalOSPrivateExecutor extends WorkerEntrypoint<Env> {
  async fetch(): Promise<Response> {
    return new Response("Not publicly reachable.", { status: 404, headers: { "cache-control": "no-store", "x-content-type-options": "nosniff" } });
  }

  async invoke(invocation: InvocationEnvelope): Promise<InvocationResult> {
    const key = `capsules/${invocation.skillId.toLowerCase()}/${invocation.capsuleCommitment.toLowerCase()}.json.enc`;
    const object = await this.env.PRIVATE_CAPSULES.get(key);
    if (!object) return { status: "blocked", outputHash: commitment({ blocked: "capsule missing" }), blockedReason: "Protected capability capsule is unavailable." };
    const encrypted = await object.json<EncryptedCapsuleEnvelope>();
    const maximumAge = Number(this.env.MAX_INVOCATION_AGE_SECONDS || 300);
    const currentTime = Math.floor(Date.now()/1000);
    if (!Number.isFinite(invocation.issuedAt) || invocation.issuedAt > currentTime + 30 || currentTime - invocation.issuedAt > maximumAge) {
      return { status: "blocked", outputHash: commitment({ blocked: "stale invocation" }), blockedReason: "Invocation envelope is stale." };
    }
    const masterKey = await loadCapsuleKey(this.env);
    const expectedAad = `GoalOS:${invocation.skillId}:${invocation.capsuleCommitment}`;
    const { capsule, plaintext } = await decryptCapsule(encrypted, masterKey, expectedAad);
    try {
      if (commitment(capsule).toLowerCase() !== invocation.capsuleCommitment.toLowerCase()) throw new Error("Capsule commitment mismatch.");
      validateCapsule(capsule, invocation);
      const maxBytes = Number(this.env.OUTPUT_MAX_BYTES || 65536);
      if (capsule.modelRoute === "deterministic") return await executeDeterministic(invocation, capsule, maxBytes);
      if (!this.env.MODEL_RUNTIME) throw new Error("Private model runtime is not bound.");
      const timeoutMs = Math.min(Number(this.env.PRIVATE_MODEL_TIMEOUT_MS || 30000), 120000);
      const response = await this.env.MODEL_RUNTIME.fetch("https://goalos-private-runtime.internal/v1/infer", {
        method: "POST",
        headers: { "content-type": "application/json", "x-goalos-request-id": invocation.requestId },
        body: JSON.stringify({
          system: capsule.systemInstruction,
          input: invocation.input,
          tools: capsule.toolAllowlist,
          policyHash: invocation.policyHash,
          outputPolicy: {
            allowedTopLevelKeys: capsule.outputPolicy.allowedTopLevelKeys || [],
            maxBytes: Math.min(capsule.outputPolicy.maxBytes, maxBytes)
          }
        }),
        signal: AbortSignal.timeout(timeoutMs)
      });
      if (!response.ok) throw new Error(`Private model runtime returned ${response.status}.`);
      const output = sanitizeOutput(await response.json(), capsule, maxBytes);
      return { status: "ok", output, outputHash: commitment(output), evidence: { handler: capsule.handlerId, executionBoundary: "MONTREAL.AI private VPC runtime", graphRoot: invocation.graphRoot } };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Execution blocked.";
      return { status: "blocked", outputHash: commitment({ blocked: message }), blockedReason: message };
    } finally {
      plaintext.fill(0);
    }
  }
}
