import { keccak256, stringToHex, type Hex } from "viem";
import type { EncryptedCapsuleEnvelope, InvocationEnvelope, InvocationResult, PrivateCapabilityCapsule } from "./types";
function normalize(value:unknown):unknown { if(Array.isArray(value)) return value.map(normalize); if(value&&typeof value==="object"){const out:Record<string,unknown>={}; for(const k of Object.keys(value as Record<string,unknown>).sort()) out[k]=normalize((value as Record<string,unknown>)[k]); return out;} if(typeof value==="bigint") return value.toString(); return value; }
export const canonicalJson=(value:unknown)=>JSON.stringify(normalize(value));
export const commitment=(value:unknown):Hex=>keccak256(stringToHex(canonicalJson(value)));
const fromB64=(v:string)=>Uint8Array.from(atob(v),c=>c.charCodeAt(0));
const decodeKey=(value:string)=>{ const bytes=fromB64(value); if(bytes.length!==32) throw new Error("Capsule master key must decode to 32 bytes."); return bytes; };
export async function decryptCapsule(envelope:EncryptedCapsuleEnvelope,keyB64:string,expectedAad:string):Promise<{capsule:PrivateCapabilityCapsule;plaintext:Uint8Array}>{
  if(envelope.algorithm!=="AES-256-GCM" || envelope.aad!==expectedAad) throw new Error("Encrypted capsule algorithm or AAD mismatch.");
  const key=await crypto.subtle.importKey("raw",decodeKey(keyB64),{name:"AES-GCM"},false,["decrypt"]);
  const plaintext=new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv:fromB64(envelope.ivB64),additionalData:new TextEncoder().encode(envelope.aad)},key,fromB64(envelope.ciphertextB64)));
  let capsule:PrivateCapabilityCapsule; try{capsule=JSON.parse(new TextDecoder().decode(plaintext));}catch{plaintext.fill(0);throw new Error("Decrypted capsule is not valid JSON.");}
  return {capsule,plaintext};
}
export function validateCapsule(c:PrivateCapabilityCapsule,i:InvocationEnvelope){
  if(c.schema!=="goalos.privateCapabilityCapsule.v1") throw new Error("Unsupported capsule schema.");
  if(c.skillId.toLowerCase()!==i.skillId.toLowerCase()||c.handlerId!==i.handlerId) throw new Error("Capsule identity mismatch.");
  if(c.scopeHash.toLowerCase()!==i.scopeHash.toLowerCase()||c.policyHash.toLowerCase()!==i.policyHash.toLowerCase()) throw new Error("Capsule scope or policy mismatch.");
  if((c.operations&i.operation)!==i.operation) throw new Error("Capsule does not permit this operation.");
  if(!c.outputPolicy||!Array.isArray(c.outputPolicy.allowedTopLevelKeys)) throw new Error("Capsule output policy is invalid.");
}
function inspect(value:unknown,c:PrivateCapabilityCapsule,depth=0):unknown{
  const p=c.outputPolicy; if(depth>p.maxDepth) throw new Error("Output depth exceeds policy.");
  if(typeof value==="string"){if(value.length>p.maxStringLength) throw new Error("Output string exceeds policy."); const low=value.toLowerCase(); for(const fragment of p.protectedFragments||[]) if(fragment&&low.includes(fragment.toLowerCase())) throw new Error("Output contains a protected fragment."); return value;}
  if(Array.isArray(value)){if(value.length>p.maxArrayLength) throw new Error("Output array exceeds policy."); return value.map(v=>inspect(v,c,depth+1));}
  if(value&&typeof value==="object"){const out:Record<string,unknown>={}; for(const [k,v] of Object.entries(value as Record<string,unknown>)){if((p.protectedFieldNames||[]).some(x=>x.toLowerCase()===k.toLowerCase())) throw new Error("Output contains a protected field name."); out[k]=inspect(v,c,depth+1);} return out;}
  if(["number","boolean","undefined"].includes(typeof value)||value===null) return value;
  throw new Error("Output contains an unsupported value type.");
}
export function sanitizeOutput(value:unknown,c:PrivateCapabilityCapsule,maximumBytes:number):unknown{
  if(!value||typeof value!=="object"||Array.isArray(value)) throw new Error("Output must be a JSON object.");
  const allowed=new Set(c.outputPolicy.allowedTopLevelKeys||[]); for(const key of Object.keys(value as Record<string,unknown>)) if(!allowed.has(key)) throw new Error(`Output key ${key} is not permitted.`);
  const clean=inspect(value,c); const bytes=new TextEncoder().encode(JSON.stringify(clean)).length; if(bytes>Math.min(maximumBytes,c.outputPolicy.maxBytes)) throw new Error("Output exceeds byte policy."); return clean;
}
export async function executeDeterministic(invocation:InvocationEnvelope,capsule:PrivateCapabilityCapsule,maxBytes:number):Promise<InvocationResult>{
  let output:unknown;
  if(capsule.handlerId==="mission-compiler-v1"){
    const objective=typeof invocation.input==="object"&&invocation.input!==null&&"objective" in invocation.input?String((invocation.input as any).objective):String(invocation.input??"");
    output={missionContract:{objective,decision:"Form a bounded proof mission",scope:"Only the stated objective and authorized tools",acceptance:"Evidence Docket supports a governed decision"},proofDebt:["Define measurable success","Identify primary evidence","Specify independent validation","Record stop and rollback conditions"],agiJobs:[{job:"Evidence acquisition",acceptance:"Primary sources and provenance captured"},{job:"Independent validation",acceptance:"Replayable verdict with blocked claims"}],nextDecision:"Approve, repair, narrow, reject, quarantine, or stop based on the Evidence Docket."};
  } else if(capsule.deterministicTemplate) output=capsule.deterministicTemplate; else throw new Error("Unknown deterministic handler.");
  const clean=sanitizeOutput(output,capsule,maxBytes); return {status:"ok",output:clean,outputHash:commitment(clean),evidence:{handler:capsule.handlerId,executionBoundary:"MONTREAL.AI protected deterministic executor",graphRoot:invocation.graphRoot}};
}
