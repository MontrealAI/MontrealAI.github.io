# GoalOS Protected Executor

The executor is designed for internal service binding only. Its public `fetch()` route returns 404. It loads encrypted capsules from private object storage, decrypts in memory, enforces identity/scope/policy/operation/output constraints, executes deterministic or private-model handlers, and releases only bounded output and commitments.

```bash
npm install
npm run verify
npm run dry-run
```
