# Architecture

## Purpose

GoalOS separates identity, candidate writes, canonical admission, entitlement, root verification, execution, and compounding into distinct gates.

```text
Direct *.agent.agi.eth identity
  -> current-owner authorization
  -> candidate graph commitment
  -> evidence and validator review
  -> Chronicle admission
  -> canonical Merkle epoch
  -> scoped revocable entitlement
  -> latest-root verification
  -> protected MONTREAL.AI execution
  -> bounded output + receipt commitment
  -> verified outcome
  -> compounding eligibility
```

## Public surfaces

- ENS identity and ownership state
- candidate and canonical roots
- public manifests and Merkle proofs
- entitlement and revocation state
- outcome commitments and invocation receipts

## Private surfaces

- encrypted capability capsules
- system instructions, methods, evaluator logic, private traces and customer-confidential context
- master keys and private model routes
- cross-customer operating graph

## Trust boundaries

1. Ethereum Mainnet establishes current identity ownership and contract state.
2. Chronicle establishes canonical capability authority.
3. Entitlements establish who may perform which operation under which scope and epoch.
4. The gateway rechecks identity, Chronicle, entitlement, and root state at challenge, session, and invocation time.
5. The internal executor decrypts and executes private capability; the public browser receives only bounded output.
