# Threat Model

## Protected assets

- private capability capsules and keys
- canonical graph authority
- entitlement integrity
- current direct-agent ownership semantics
- invocation inputs, outputs, and receipts

## Principal threats

- nested-name escalation or wrong-namespace identity claims
- stale ENS ownership after transfer or wrapped-name expiry
- candidate self-admission into canonical memory
- stale-root replay
- operation or scope escalation
- challenge/session replay
- compromised or unapproved Name Wrapper
- root equivocation, leaf tampering, or canonicalization drift
- public exposure of capsule plaintext, keys, prompts, traces, or private model routes
- malicious output attempting to exfiltrate protected fields
- validator capture or false verified-outcome recording

## Core mitigations

- exact direct-child node derivation beneath `agent.agi.eth`
- current Registry or approved Name Wrapper ownership checks with expiry
- separate candidate and Chronicle registries
- scoped, time-bounded, epoch-bounded, revocable operation entitlements
- one-use EIP-712 challenges and one-use sessions
- latest-root and policy rechecks immediately before execution
- domain-separated canonical leaves and sorted-pair Merkle verification
- encrypted off-chain capsules; no plaintext private intelligence on public surfaces
- internal service binding for the executor; public route returns 404
- strict output schema, byte/depth limits, and protected-fragment filtering
- emergency pause, revocation, supersession, retirement, and incident procedures

## Residual risk

The architecture does not eliminate smart-contract bugs, cryptographic implementation errors, wallet compromise, validator collusion, cloud compromise, model exfiltration, legal obligations, or operational mistakes. Independent review and live acceptance are required.
