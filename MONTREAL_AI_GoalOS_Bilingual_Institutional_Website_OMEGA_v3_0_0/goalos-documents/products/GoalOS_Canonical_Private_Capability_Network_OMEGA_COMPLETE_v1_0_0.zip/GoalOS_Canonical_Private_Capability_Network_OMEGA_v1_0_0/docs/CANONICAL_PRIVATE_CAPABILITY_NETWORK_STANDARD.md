# GoalOS Canonical Private Capability Network Ω — Normative Standard

## Purpose

This standard defines the MONTREAL.AI-controlled capability network beneath `agent.agi.eth`. The protocol and verifier may remain open. Canonical capability, entitlement, and protected execution remain governed.

## Final law

1. **No direct name, no identity.**
2. **No current ownership, no write.**
3. **No Chronicle admission, no canonical skill.**
4. **No entitlement, no use.**
5. **No latest-root proof, no reliance.**
6. **No verified outcome, no compounding.**

All six statements are conjunctive and fail closed.

## Authority separation

| Authority | Object | What it permits |
|---|---|---|
| Identity | Current direct `label.agent.agi.eth` owner | Candidate write request and access authentication |
| Candidate registry | Agent-owned candidate root | Append-auditable submission only; no canonical influence |
| Chronicle | Canonical epoch and skill status | Admission, repair, rejection, revocation, supersession, retirement |
| Entitlement registry | Skill + operation + scope + policy + epoch + time | Specific use by the current direct identity owner |
| Latest-root verifier | Canonical skill leaf and Merkle proof | Reliance on the current admitted graph state |
| Protected executor | Encrypted capsule and private runtime | Bounded invocation without raw capability disclosure |
| Outcome authority | Mission outcome root and independent validator | Eligibility to compound into later missions |

No layer may silently inherit the power of another.

## Direct identity invariant

Let `P = namehash(agent.agi.eth)` and `L = labelhash(label)`. The only authorized identity node is:

```text
N = keccak256(P || L)
```

The system accepts `alice.agent.agi.eth` and rejects:

```text
agent.agi.eth
x.alice.agent.agi.eth
alice.club.agi.eth
```

The current owner must be read from the Ethereum Mainnet ENS Registry or an explicitly approved Name Wrapper. Wrapped ownership must be nonzero and unexpired.

## Write invariant

A current direct owner may append a candidate graph root for its exact label. Candidate roots preserve chronology but do not confer future-mission authority. A transferred or expired name immediately loses write authority.

## Chronicle invariant

Only a separated Chronicle authority may establish the canonical epoch and change a skill's authority state. The canonical state is append-auditable, previous-root-bound, policy-bound, schema-bound, and revocable.

## Entitlement invariant

An entitlement is deterministic and binds:

```text
agentNode
skillId
scopeHash
policyHash
operation mask
not-before and expiry
minimum and maximum epoch
revocation state
```

The entitlement follows the current direct identity owner. It is not permanently attached to the wallet that first received it.

## Invocation invariant

Invocation is authorized only when all of these are true at execution time:

```text
exact direct name
+ current owner
+ fresh one-use authorization
+ current scoped entitlement
+ current Chronicle policy
+ active skill
+ latest canonical root
+ valid canonical leaf
+ valid Merkle proof
+ matching private capsule commitment
+ protected executor
```

A client cannot select its entitlement ID, policy, root, private capsule, handler, or execution route.

## Protected execution invariant

The browser receives only:

- public capability metadata;
- readable signing request;
- bounded result;
- output hash;
- receipt commitment;
- canonical root reference.

The browser never receives:

- system instructions;
- full skill capsule;
- reviewer notes;
- model or tool traces;
- decryption keys;
- cross-customer capability intelligence;
- generic private model access.

Encrypted capsules are stored separately from public manifests. The internal executor has no public route and may call models or tools only through pre-registered MONTREAL.AI private services.

## Compounding invariant

Successful invocation is not proof of real-world value. A capability becomes compounding-eligible only after an independently verified mission outcome is recorded while the capability remains active.

## Required denial behavior

The system MUST deny on:

- RPC ambiguity or failure;
- unknown or unapproved wrapper;
- expired wrapped name;
- ownership mismatch or transfer;
- missing, expired, revoked, or scope-incompatible entitlement;
- inactive, revoked, retired, superseded, expired, or policy-stale skill;
- stale root;
- missing manifest;
- leaf or proof mismatch;
- capsule commitment mismatch;
- stale invocation envelope;
- output-boundary failure;
- private-runtime failure;
- uncertain policy state.

## Production designation

The implementation may be called **production activated** only after:

- deployed Mainnet contracts and roles are independently reviewed;
- controlled wrapped, unwrapped, transfer, expiry, nested-name, and smart-wallet acceptance tests pass;
- protected executor and key-management controls pass security review;
- no public route or static asset can expose private capability;
- incident pause, revocation, root migration, capsule retirement, and recovery are rehearsed;
- an external reviewer reproduces the root and access checks.
