# Packaging and Integrity

The final archive is deterministic: entries are sorted, timestamps are normalized, and generated caches, dependencies, secrets, and local environment files are excluded.

- `FINAL_RELEASE_MANIFEST.json` lists release files, sizes, and SHA-256 digests.
- `SHA256SUMS.txt` lists per-file SHA-256 values.
- the external download checksum file records the archive digest.
- `PACKAGE_VERIFICATION.json` records extraction and integrity verification.

Verify on macOS or Linux:

```bash
shasum -a 256 -c SHA256SUMS.txt
```

Verify the downloaded ZIP using the digest published alongside it before extraction.
