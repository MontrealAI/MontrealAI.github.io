# Production Deployment Runbook

## Phase 0 — Freeze

1. Freeze contract source, schemas, operation masks, root policy, approved wrappers, challenge TTL, session TTL, log policy, and incident roles.
2. Record source SHA-256 values and signed release tag.
3. Obtain external contract, cryptography, cloud, and privacy review.

## Phase 1 — ENS and authority

1. Confirm MONTREAL.AI governance of `agent.agi.eth`.
2. Compute and independently verify `namehash(agent.agi.eth)`.
3. Inspect representative direct names in the ENS Registry.
4. Determine the exact Name Wrapper contract currently owning wrapped direct names.
5. Approve only reviewed wrapper addresses. Do not blindly retain legacy wrappers.
6. Test an unwrapped direct name, wrapped direct name, expired name, transferred name, nested name, wrong namespace, and contract-wallet owner.

## Phase 2 — Contracts

1. Deploy `GoalOSChronicleRegistry` behind a MONTREAL.AI Safe / multisig administration policy.
2. Deploy `GoalOSAgentCandidateRegistry` for direct-owner candidate root submissions.
3. Deploy `GoalOSEntitlementRegistry` with Ethereum Mainnet ENS Registry, the fixed parent node, Chronicle address, and admin.
4. Grant Chronicle, Outcome, Entitlement, Wrapper, and Emergency roles to separated authorities.
5. Approve the exact Name Wrapper set on both candidate and entitlement registries.
6. Commit the first canonical epoch with previous-root continuity.
7. Admit only skills whose public manifest and private capsule commitments match the frozen schemas.
8. Grant deterministic scoped entitlements.

## Phase 3 — Data planes

1. Create separate public-manifest and private-capsule buckets.
2. Bind a 256-bit capsule key from an account-level Secrets Store or private KMS/key broker.
3. Prefer per-capsule data-encryption keys wrapped by a separately governed key-encryption key.
4. Encrypt every private capsule with unique AES-GCM IV and contextual AAD.
5. Make key material available only to the executor or private key broker; never the gateway.
6. Upload public manifests to the gateway-readable bucket and encrypted capsules to the executor-only bucket.

## Phase 4 — Private runtime

1. Deploy the executor without a public route.
2. Bind it to the gateway through a Worker Service Binding.
3. For model-based skills, bind the executor to a pre-registered private VPC service. Do not call a public model endpoint.
4. Enforce egress allowlists and metadata-only logs.
5. Verify that plaintext instructions never appear in responses, errors, traces, analytics, or crash reports.

## Phase 5 — Gateway and client

1. Deploy D1 migrations.
2. Configure RPC secret, HMAC secret, registry addresses, allowed origin, wrapper list, and storage bindings.
3. Serve the static client from the same Worker origin.
4. Enable HSTS, no-store, restrictive CSP, origin checks, request limits, and fail-closed routes.
5. Run one-use challenge, ERC-1271, session replay, transfer, revocation, root-change, and proof-tamper tests.

## Phase 6 — Activation

Production activation is authorized only after every item in `LIVE_ACCEPTANCE_CHECKLIST.md` passes and the deployed addresses, ABI hashes, schema hashes, policy hash, root packet, rollback process, and reviewer report are published.
