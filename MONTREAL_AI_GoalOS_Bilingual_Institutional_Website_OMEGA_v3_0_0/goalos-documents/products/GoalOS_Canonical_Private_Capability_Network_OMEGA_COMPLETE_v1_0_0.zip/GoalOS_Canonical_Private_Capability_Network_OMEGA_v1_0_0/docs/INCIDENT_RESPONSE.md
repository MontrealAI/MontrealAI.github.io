# Incident Response

## Immediate containment

1. Pause the Entitlement Registry.
2. Revoke the affected Chronicle epoch or skill.
3. Disable the gateway route and private executor binding.
4. Revoke all active sessions and challenges.
5. Rotate capsule keys, gateway HMAC secret, operator keys, and affected service credentials.
6. Preserve logs, commitments, root packets, and transaction evidence without exposing plaintext capability.

## Recovery

1. Classify identity, entitlement, root, proof, key, executor, output, or validator failure.
2. Produce an Evidence Docket and root-cause report.
3. Supersede rather than delete affected skills and roots.
4. Commit a new policy-bound epoch with previous-root continuity or a documented migration root.
5. Regrant minimum entitlements.
6. Run all acceptance tests plus an external replay before unpausing.

## Public disclosure

Publish commitments, affected epochs, revocations, timeline, customer impact, remediation, and independent review. Do not publish private capsules, customer data, keys, or exploit-enabling details before containment.
