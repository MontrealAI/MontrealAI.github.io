# Protected Execution Boundary

## Non-negotiable rule

Private capability must never be shipped to a browser, public repository, public object store, public API response, analytics event, error trace, or customer-controlled runtime.

## Production topology

```text
Same-origin client
  ↓
Public GoalOS gateway
  - current ENS ownership
  - signature freshness and replay control
  - scoped entitlement
  - current Chronicle state
  - latest-root Merkle proof
  ↓ internal Service Binding only
Private GoalOS executor
  - no public route
  - private encrypted capsule store
  - key from secrets/KMS
  - commitment check
  - output policy and DLP
  ↓ private VPC binding only
MONTREAL.AI-controlled model/tool runtime
```

## Required controls

- Serve the invocation client and gateway from the same MONTREAL.AI-controlled HTTPS origin.
- Use `__Host-`, `Secure`, `HttpOnly`, `SameSite=Strict` one-use or short-lived sessions.
- Recheck current ENS ownership, entitlement, skill status, policy, and root on every invocation.
- Store only public manifests in the gateway's readable bucket.
- Store encrypted capsules in a separate bucket visible only to the executor.
- Bind decryption material from an account-level Secrets Store or a private key-broker/KMS, never source code or static configuration. Use unique capsule IVs, contextual AAD, rotation, and crypto-erasure procedures.
- Give the executor no public route and no generic Internet egress.
- Permit model/tool calls only through pre-registered private VPC services.
- Keep logs metadata-only: request ID, hashes, timing, policy, result status. Do not log plaintext inputs, outputs, instructions, traces, capsules, or keys.
- Apply actual-byte request limits, output-size/depth/string/array limits, forbidden-field and forbidden-fragment controls, and an allowlisted response schema.
- Batch public receipt commitments; keep sensitive usage details private.
- Rotate keys and invalidate sessions after identity transfer, entitlement revocation, skill revocation, root migration, or incident declaration.

## Static-hosting boundary

GitHub Pages or IPFS may host public documentation and a public verifier. They cannot enforce secrecy for private capability delivered to a browser. Protected invocation therefore requires a MONTREAL.AI-controlled server-side gateway and internal executor.
