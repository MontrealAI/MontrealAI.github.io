# Live Mainnet Acceptance Checklist

## Identity and candidate writes

- [ ] Current direct owner can append a candidate root for its exact label.
- [ ] Non-owner cannot append a candidate root.
- [ ] Transfer immediately removes the old owner's candidate-write authority.
- [ ] Candidate root cannot influence a mission or become canonical without Chronicle.

- [ ] Direct unwrapped owner can request and invoke.
- [ ] Direct wrapped owner can request and invoke.
- [ ] Nested descendant is rejected.
- [ ] Parent name is rejected.
- [ ] Wrong namespace is rejected.
- [ ] Wrong wallet is rejected.
- [ ] Expired wrapped name is rejected.
- [ ] Ownership transfer invalidates the old wallet immediately.
- [ ] ERC-1271 smart-account owner can authenticate.

## Entitlement

- [ ] No entitlement is rejected.
- [ ] Revoked entitlement is rejected.
- [ ] Future-dated entitlement is rejected.
- [ ] Expired entitlement is rejected.
- [ ] Wrong skill is rejected.
- [ ] Wrong operation is rejected.
- [ ] Wrong scope is rejected.
- [ ] Wrong policy is rejected.
- [ ] Epoch below minimum or above maximum is rejected.

## Chronicle and root

- [ ] Candidate skill is rejected.
- [ ] Revoked, retired, or superseded skill is rejected.
- [ ] Modified leaf fails.
- [ ] Modified proof path fails.
- [ ] Stale root fails after a new epoch.
- [ ] Wrong schema hash fails.
- [ ] Wrong policy hash fails.
- [ ] Root continuity violation reverts.
- [ ] Emergency epoch revocation pauses access.

## Execution boundary

- [ ] Executor has no public route.
- [ ] Gateway cannot read the private capsule bucket.
- [ ] Client bundle contains no capsule, key, private prompt, or model route.
- [ ] Private capsule commitment is checked after decryption.
- [ ] Private model runtime is reachable only through the approved private binding.
- [ ] Public Internet egress from the executor is denied or policy-blocked.
- [ ] Plaintext is absent from application logs, traces, analytics, and error reports.
- [ ] Output disclosure test blocks protected fragments.
- [ ] Decryption-key rotation invalidates retired capsules.

## Replay and sessions

- [ ] Challenge can be consumed only once.
- [ ] Expired challenge fails.
- [ ] Origin mismatch fails.
- [ ] Input-hash mismatch fails.
- [ ] Cross-chain or cross-contract signature replay fails.
- [ ] Exhausted session fails.
- [ ] Concurrent duplicate invocation produces at most one execution.

## Outcomes and compounding

- [ ] Invocation alone does not set `canCompound`.
- [ ] Independently verified outcome updates the outcome root.
- [ ] Revoked skill cannot compound despite prior outcomes.
- [ ] Fresh successor comparison uses the admitted capability and frozen baseline.
