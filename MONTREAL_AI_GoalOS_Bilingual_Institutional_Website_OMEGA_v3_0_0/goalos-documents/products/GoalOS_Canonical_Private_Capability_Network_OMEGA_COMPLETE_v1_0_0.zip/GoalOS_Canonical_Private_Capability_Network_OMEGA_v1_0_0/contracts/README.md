# Smart Contracts

```bash
npm install
npm run verify
```

The package compiles with `solc` and executes nine Ganache-based authorization tests. The deployment contracts are `GoalOSDirectAgentAuthorizer`, `GoalOSAgentCandidateRegistry`, `GoalOSChronicleRegistry`, and `GoalOSEntitlementRegistry`. Mocks are test-only.
