import fs from "node:fs"; import path from "node:path"; import solc from "solc";
const root=path.resolve("."); const contractsDir=path.join(root,"contracts"); const artifactsDir=path.join(root,"artifacts");
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]).filter(x=>x.endsWith(".sol"));}
const sources={}; for(const file of walk(contractsDir)){sources[path.relative(root,file).replaceAll(path.sep,"/")]={content:fs.readFileSync(file,"utf8")};}
const input={language:"Solidity",sources,settings:{optimizer:{enabled:true,runs:200},outputSelection:{"*":{"*":["abi","evm.bytecode.object","evm.deployedBytecode.object","metadata"]}}}};
function findImports(importPath){
  const candidates=[path.join(root,importPath),path.join(root,"contracts",importPath),path.join(root,"node_modules",importPath)];
  for(const p of candidates) if(fs.existsSync(p)) return {contents:fs.readFileSync(p,"utf8")};
  return {error:`File not found: ${importPath}`};
}
const output=JSON.parse(solc.compile(JSON.stringify(input),{import:findImports}));
const errors=(output.errors||[]).filter(e=>e.severity==="error"); if(errors.length){console.error(errors.map(e=>e.formattedMessage).join("\n"));process.exit(1);} fs.rmSync(artifactsDir,{recursive:true,force:true}); fs.mkdirSync(artifactsDir,{recursive:true});
let count=0; for(const [source,contracts] of Object.entries(output.contracts||{})){for(const [name,artifact] of Object.entries(contracts)){if(!artifact.evm?.bytecode?.object) continue; const out={contractName:name,sourceName:source,abi:artifact.abi,bytecode:`0x${artifact.evm.bytecode.object}`,deployedBytecode:`0x${artifact.evm.deployedBytecode.object}`,compiler:solc.version()}; fs.writeFileSync(path.join(artifactsDir,`${name}.json`),JSON.stringify(out,null,2)); count++;}}
console.log(`Compiled ${count} deployable contracts with ${solc.version()}.`);
