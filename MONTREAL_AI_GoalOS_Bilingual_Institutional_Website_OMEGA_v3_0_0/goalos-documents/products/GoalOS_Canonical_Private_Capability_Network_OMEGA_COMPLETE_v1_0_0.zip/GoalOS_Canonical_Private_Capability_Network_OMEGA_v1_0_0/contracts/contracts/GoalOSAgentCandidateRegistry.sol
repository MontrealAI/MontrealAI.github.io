// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {GoalOSDirectAgentAuthorizer} from "./GoalOSDirectAgentAuthorizer.sol";

/// @notice Append-auditable candidate graph commitments for direct *.agent.agi.eth identities.
/// @dev Candidate roots never confer Chronicle admission or future-mission authority.
///      The current direct ENS owner may write only for its exact direct label.
contract GoalOSAgentCandidateRegistry is GoalOSDirectAgentAuthorizer, Pausable {
    bytes32 public constant EMERGENCY_ROLE = keccak256("EMERGENCY_ROLE");

    struct CandidateEpoch {
        bytes32 root;
        bytes32 previousRoot;
        bytes32 packetHash;
        bytes32 policyHash;
        bytes32 schemaHash;
        address writer;
        uint64 committedAt;
        bool revoked;
    }

    mapping(bytes32 => uint64) public latestCandidateEpoch;
    mapping(bytes32 => bytes32) public latestCandidateRoot;
    mapping(bytes32 => mapping(uint64 => CandidateEpoch)) private _candidateEpochs;

    event CandidateEpochCommitted(
        bytes32 indexed labelhash,
        bytes32 indexed agentNode,
        uint64 indexed epoch,
        bytes32 root,
        bytes32 previousRoot,
        bytes32 packetHash,
        bytes32 policyHash,
        bytes32 schemaHash,
        address writer
    );
    event CandidateEpochRevoked(
        bytes32 indexed labelhash,
        uint64 indexed epoch,
        bytes32 indexed root,
        bytes32 reasonHash,
        address actor
    );

    error NotCurrentDirectOwner();
    error InvalidCandidateRoot();
    error CandidateRootContinuityViolation();
    error InvalidCandidateEpoch();

    constructor(address ensRegistry, bytes32 agentParentNode, address admin)
        GoalOSDirectAgentAuthorizer(ensRegistry, agentParentNode, admin)
    {
        _grantRole(EMERGENCY_ROLE, admin);
    }

    function pause() external onlyRole(EMERGENCY_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }

    function commitCandidateEpoch(
        bytes32 labelhash,
        bytes32 newRoot,
        bytes32 expectedPreviousRoot,
        bytes32 packetHash,
        bytes32 policyHash,
        bytes32 schemaHash
    ) external whenNotPaused returns (uint64 epoch) {
        if (!isCurrentDirectOwner(labelhash, msg.sender)) revert NotCurrentDirectOwner();
        if (
            newRoot == bytes32(0) ||
            packetHash == bytes32(0) ||
            policyHash == bytes32(0) ||
            schemaHash == bytes32(0)
        ) revert InvalidCandidateRoot();
        if (expectedPreviousRoot != latestCandidateRoot[labelhash]) {
            revert CandidateRootContinuityViolation();
        }

        epoch = latestCandidateEpoch[labelhash] + 1;
        _candidateEpochs[labelhash][epoch] = CandidateEpoch({
            root: newRoot,
            previousRoot: expectedPreviousRoot,
            packetHash: packetHash,
            policyHash: policyHash,
            schemaHash: schemaHash,
            writer: msg.sender,
            committedAt: uint64(block.timestamp),
            revoked: false
        });
        latestCandidateEpoch[labelhash] = epoch;
        latestCandidateRoot[labelhash] = newRoot;

        emit CandidateEpochCommitted(
            labelhash,
            directAgentNode(labelhash),
            epoch,
            newRoot,
            expectedPreviousRoot,
            packetHash,
            policyHash,
            schemaHash,
            msg.sender
        );
    }

    /// @notice Current direct owner may revoke its latest candidate epoch; an emergency
    ///         authority may revoke any latest candidate epoch during incident response.
    /// @dev Revocation preserves provenance and does not rewind the append-only root chain.
    function revokeLatestCandidateEpoch(bytes32 labelhash, bytes32 reasonHash) external {
        bool isOwner = isCurrentDirectOwner(labelhash, msg.sender);
        if (!isOwner && !hasRole(EMERGENCY_ROLE, msg.sender)) revert NotCurrentDirectOwner();
        uint64 epoch = latestCandidateEpoch[labelhash];
        if (epoch == 0) revert InvalidCandidateEpoch();
        CandidateEpoch storage record = _candidateEpochs[labelhash][epoch];
        record.revoked = true;
        emit CandidateEpochRevoked(labelhash, epoch, record.root, reasonHash, msg.sender);
    }

    function candidateEpoch(bytes32 labelhash, uint64 epoch)
        external
        view
        returns (CandidateEpoch memory)
    {
        return _candidateEpochs[labelhash][epoch];
    }
}
