// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
interface IGoalOSChronicleRegistry {
  function currentPolicyHash() external view returns (bytes32);
  function latestEpoch() external view returns (uint64);
  function currentRoot() external view returns (bytes32);
  function isSkillActive(bytes32 skillId) external view returns (bool);
}
