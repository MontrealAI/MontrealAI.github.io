// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
interface IENSRegistry { function owner(bytes32 node) external view returns (address); }
