// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
interface INameWrapper { function getData(uint256 id) external view returns (address owner, uint32 fuses, uint64 expiry); }
