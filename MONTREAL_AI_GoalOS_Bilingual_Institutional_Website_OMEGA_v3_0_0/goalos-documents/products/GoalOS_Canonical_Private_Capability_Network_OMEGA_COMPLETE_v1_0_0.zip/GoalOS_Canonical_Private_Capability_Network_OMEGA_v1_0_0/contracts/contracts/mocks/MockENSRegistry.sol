// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
contract MockENSRegistry {
  mapping(bytes32 => address) public owner;
  function setOwner(bytes32 node, address newOwner) external { owner[node] = newOwner; }
}
