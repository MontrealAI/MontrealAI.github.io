// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
contract MockNameWrapper {
  struct Data { address owner; uint32 fuses; uint64 expiry; }
  mapping(uint256 => Data) private _data;
  function setData(uint256 id, address owner_, uint32 fuses_, uint64 expiry_) external { _data[id] = Data(owner_, fuses_, expiry_); }
  function getData(uint256 id) external view returns (address owner_, uint32 fuses_, uint64 expiry_) { Data memory d=_data[id]; return (d.owner,d.fuses,d.expiry); }
}
