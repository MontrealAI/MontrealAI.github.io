// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {IENSRegistry} from "./interfaces/IENSRegistry.sol";
import {INameWrapper} from "./interfaces/INameWrapper.sol";

/// @notice Resolves only direct children of the configured agent.agi.eth parent.
/// @dev Nested descendants can never be represented because the node is always
///      keccak256(parentNode || labelhash).
abstract contract GoalOSDirectAgentAuthorizer is AccessControl {
    bytes32 public constant WRAPPER_ADMIN_ROLE = keccak256("WRAPPER_ADMIN_ROLE");

    IENSRegistry public immutable ensRegistry;
    bytes32 public immutable agentParentNode;
    mapping(address => bool) public approvedNameWrappers;

    event NameWrapperApprovalChanged(address indexed wrapper, bool approved);

    error ZeroAddress();
    error ZeroParentNode();

    constructor(address ensRegistry_, bytes32 agentParentNode_, address admin) {
        if (ensRegistry_ == address(0) || admin == address(0)) revert ZeroAddress();
        if (agentParentNode_ == bytes32(0)) revert ZeroParentNode();
        ensRegistry = IENSRegistry(ensRegistry_);
        agentParentNode = agentParentNode_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(WRAPPER_ADMIN_ROLE, admin);
    }

    function setApprovedNameWrapper(address wrapper, bool approved)
        external
        onlyRole(WRAPPER_ADMIN_ROLE)
    {
        if (wrapper == address(0)) revert ZeroAddress();
        approvedNameWrappers[wrapper] = approved;
        emit NameWrapperApprovalChanged(wrapper, approved);
    }

    function directAgentNode(bytes32 labelhash) public view returns (bytes32) {
        return keccak256(abi.encodePacked(agentParentNode, labelhash));
    }

    /// @return owner Current direct-name owner.
    /// @return wrapped Whether ownership is represented by an approved Name Wrapper.
    /// @return active Whether a nonzero, nonexpired owner was found.
    /// @return expiry Wrapped expiry; zero for unwrapped names.
    function currentDirectOwner(bytes32 labelhash)
        public
        view
        returns (address owner, bool wrapped, bool active, uint64 expiry)
    {
        bytes32 node = directAgentNode(labelhash);
        address registryOwner = ensRegistry.owner(node);
        if (registryOwner == address(0)) return (address(0), false, false, 0);

        if (!approvedNameWrappers[registryOwner]) {
            return (registryOwner, false, true, 0);
        }

        try INameWrapper(registryOwner).getData(uint256(node)) returns (
            address wrappedOwner,
            uint32,
            uint64 wrappedExpiry
        ) {
            bool isActive = wrappedOwner != address(0) && wrappedExpiry > block.timestamp;
            return (wrappedOwner, true, isActive, wrappedExpiry);
        } catch {
            return (address(0), true, false, 0);
        }
    }

    function isCurrentDirectOwner(bytes32 labelhash, address claimant) public view returns (bool) {
        if (claimant == address(0)) return false;
        (address owner,, bool active,) = currentDirectOwner(labelhash);
        return active && owner == claimant;
    }
}
