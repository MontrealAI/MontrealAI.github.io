// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

/// @notice Canonical Chronicle authority for private GoalOS capability roots.
/// @dev Merkle inclusion remains separately verified by the gateway. This contract
///      records canonical epochs, skill authority state, revocation and outcome gates.
contract GoalOSChronicleRegistry is AccessControl, Pausable {
    bytes32 public constant CHRONICLE_ROLE = keccak256("CHRONICLE_ROLE");
    bytes32 public constant OUTCOME_ROLE = keccak256("OUTCOME_ROLE");
    bytes32 public constant EMERGENCY_ROLE = keccak256("EMERGENCY_ROLE");

    enum SkillStatus { NONE, ACTIVE, REVOKED, SUPERSEDED, RETIRED }

    struct EpochRecord {
        bytes32 root;
        bytes32 previousRoot;
        bytes32 policyHash;
        bytes32 schemaHash;
        bytes32 rootPacketHash;
        uint64 activatedAt;
        bool revoked;
    }

    struct SkillRecord {
        bytes32 leafHash;
        bytes32 scopeHash;
        bytes32 policyHash;
        bytes32 successorSkillId;
        bytes32 latestOutcomeRoot;
        uint64 admittedEpoch;
        uint64 notBefore;
        uint64 expiresAt;
        uint64 verifiedOutcomeCount;
        SkillStatus status;
    }

    uint64 public latestEpoch;
    bytes32 public currentRoot;
    bytes32 public currentPolicyHash;
    bytes32 public currentSchemaHash;

    mapping(uint64 => EpochRecord) public epochs;
    mapping(bytes32 => SkillRecord) private _skills;

    event EpochCommitted(
        uint64 indexed epoch,
        bytes32 indexed root,
        bytes32 indexed previousRoot,
        bytes32 policyHash,
        bytes32 schemaHash,
        bytes32 rootPacketHash
    );
    event EpochRevoked(uint64 indexed epoch, bytes32 indexed root, bytes32 reasonHash);
    event SkillAdmitted(bytes32 indexed skillId, bytes32 leafHash, bytes32 scopeHash, uint64 indexed epoch);
    event SkillRevoked(bytes32 indexed skillId, bytes32 reasonHash);
    event SkillSuperseded(bytes32 indexed oldSkillId, bytes32 indexed newSkillId, bytes32 reasonHash);
    event SkillRetired(bytes32 indexed skillId, bytes32 reasonHash);
    event VerifiedOutcomeRecorded(bytes32 indexed skillId, bytes32 indexed missionId, bytes32 outcomeRoot, address indexed validator);

    error InvalidRoot();
    error RootContinuityViolation();
    error InvalidEpoch();
    error InvalidSkill();
    error InvalidTimeRange();
    error SkillNotActive();

    constructor(address admin) {
        if (admin == address(0)) revert InvalidSkill();
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(CHRONICLE_ROLE, admin);
        _grantRole(OUTCOME_ROLE, admin);
        _grantRole(EMERGENCY_ROLE, admin);
    }

    function pause() external onlyRole(EMERGENCY_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }

    function commitEpoch(
        bytes32 newRoot,
        bytes32 expectedPreviousRoot,
        bytes32 policyHash,
        bytes32 schemaHash,
        bytes32 rootPacketHash
    ) external onlyRole(CHRONICLE_ROLE) whenNotPaused returns (uint64 epoch) {
        if (newRoot == bytes32(0) || policyHash == bytes32(0) || schemaHash == bytes32(0)) revert InvalidRoot();
        if (expectedPreviousRoot != currentRoot) revert RootContinuityViolation();

        epoch = latestEpoch + 1;
        epochs[epoch] = EpochRecord({
            root: newRoot,
            previousRoot: currentRoot,
            policyHash: policyHash,
            schemaHash: schemaHash,
            rootPacketHash: rootPacketHash,
            activatedAt: uint64(block.timestamp),
            revoked: false
        });
        latestEpoch = epoch;
        currentRoot = newRoot;
        currentPolicyHash = policyHash;
        currentSchemaHash = schemaHash;
        emit EpochCommitted(epoch, newRoot, expectedPreviousRoot, policyHash, schemaHash, rootPacketHash);
    }

    function revokeCurrentEpoch(bytes32 reasonHash) external onlyRole(EMERGENCY_ROLE) {
        uint64 epoch = latestEpoch;
        if (epoch == 0) revert InvalidEpoch();
        epochs[epoch].revoked = true;
        emit EpochRevoked(epoch, epochs[epoch].root, reasonHash);
        _pause();
    }

    function admitSkill(
        bytes32 skillId,
        bytes32 leafHash,
        bytes32 scopeHash,
        bytes32 policyHash,
        uint64 notBefore,
        uint64 expiresAt
    ) external onlyRole(CHRONICLE_ROLE) whenNotPaused {
        if (skillId == bytes32(0) || leafHash == bytes32(0) || scopeHash == bytes32(0)) revert InvalidSkill();
        if (latestEpoch == 0 || policyHash != currentPolicyHash) revert InvalidEpoch();
        if (expiresAt != 0 && expiresAt <= notBefore) revert InvalidTimeRange();

        SkillRecord storage record = _skills[skillId];
        record.leafHash = leafHash;
        record.scopeHash = scopeHash;
        record.policyHash = policyHash;
        record.successorSkillId = bytes32(0);
        record.admittedEpoch = latestEpoch;
        record.notBefore = notBefore;
        record.expiresAt = expiresAt;
        record.status = SkillStatus.ACTIVE;
        emit SkillAdmitted(skillId, leafHash, scopeHash, latestEpoch);
    }

    function revokeSkill(bytes32 skillId, bytes32 reasonHash) external onlyRole(CHRONICLE_ROLE) {
        SkillRecord storage record = _skills[skillId];
        if (record.status != SkillStatus.ACTIVE) revert SkillNotActive();
        record.status = SkillStatus.REVOKED;
        emit SkillRevoked(skillId, reasonHash);
    }

    function supersedeSkill(bytes32 oldSkillId, bytes32 newSkillId, bytes32 reasonHash)
        external
        onlyRole(CHRONICLE_ROLE)
    {
        SkillRecord storage oldRecord = _skills[oldSkillId];
        if (oldRecord.status != SkillStatus.ACTIVE || _skills[newSkillId].status != SkillStatus.ACTIVE) {
            revert SkillNotActive();
        }
        oldRecord.status = SkillStatus.SUPERSEDED;
        oldRecord.successorSkillId = newSkillId;
        emit SkillSuperseded(oldSkillId, newSkillId, reasonHash);
    }

    function retireSkill(bytes32 skillId, bytes32 reasonHash) external onlyRole(CHRONICLE_ROLE) {
        SkillRecord storage record = _skills[skillId];
        if (record.status != SkillStatus.ACTIVE) revert SkillNotActive();
        record.status = SkillStatus.RETIRED;
        emit SkillRetired(skillId, reasonHash);
    }

    function recordVerifiedOutcome(
        bytes32 skillId,
        bytes32 missionId,
        bytes32 outcomeRoot,
        address validator
    ) external onlyRole(OUTCOME_ROLE) whenNotPaused {
        if (!isSkillActive(skillId) || missionId == bytes32(0) || outcomeRoot == bytes32(0) || validator == address(0)) {
            revert InvalidSkill();
        }
        SkillRecord storage record = _skills[skillId];
        record.verifiedOutcomeCount += 1;
        record.latestOutcomeRoot = outcomeRoot;
        emit VerifiedOutcomeRecorded(skillId, missionId, outcomeRoot, validator);
    }

    function skillRecord(bytes32 skillId) external view returns (SkillRecord memory) {
        return _skills[skillId];
    }

    function isSkillActive(bytes32 skillId) public view returns (bool) {
        if (paused() || latestEpoch == 0 || epochs[latestEpoch].revoked) return false;
        SkillRecord storage record = _skills[skillId];
        if (record.status != SkillStatus.ACTIVE) return false;
        if (record.policyHash != currentPolicyHash) return false;
        if (block.timestamp < record.notBefore) return false;
        if (record.expiresAt != 0 && block.timestamp >= record.expiresAt) return false;
        return true;
    }

    function canCompound(bytes32 skillId) external view returns (bool) {
        return isSkillActive(skillId) && _skills[skillId].verifiedOutcomeCount > 0;
    }
}
