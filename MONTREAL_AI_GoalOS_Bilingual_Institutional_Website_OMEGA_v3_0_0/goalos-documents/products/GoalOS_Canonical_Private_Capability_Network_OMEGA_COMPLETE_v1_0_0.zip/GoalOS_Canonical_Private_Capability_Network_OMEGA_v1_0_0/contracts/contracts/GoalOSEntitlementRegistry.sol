// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {GoalOSDirectAgentAuthorizer} from "./GoalOSDirectAgentAuthorizer.sol";
import {IGoalOSChronicleRegistry} from "./interfaces/IGoalOSChronicleRegistry.sol";

/// @notice Scoped, revocable authorization for direct *.agent.agi.eth identities.
/// @dev Entitlements follow the current direct ENS identity owner, not the wallet
///      that originally received the entitlement.
contract GoalOSEntitlementRegistry is GoalOSDirectAgentAuthorizer, Pausable {
    bytes32 public constant ENTITLEMENT_ADMIN_ROLE = keccak256("ENTITLEMENT_ADMIN_ROLE");
    bytes32 public constant EMERGENCY_ROLE = keccak256("EMERGENCY_ROLE");

    bytes32 public constant ENTITLEMENT_DOMAIN = keccak256("GoalOSEntitlementV1");

    uint256 public constant OP_SUBMIT_CANDIDATE = 1 << 0;
    uint256 public constant OP_INVOKE = 1 << 1;
    uint256 public constant OP_COMPOSE = 1 << 2;
    uint256 public constant OP_TEACH = 1 << 3;
    uint256 public constant OP_PACKAGE = 1 << 4;
    uint256 public constant OP_AUDIT = 1 << 5;

    struct Entitlement {
        bytes32 agentNode;
        bytes32 skillId;
        bytes32 scopeHash;
        bytes32 policyHash;
        uint256 operations;
        uint64 notBefore;
        uint64 expiresAt;
        uint64 minEpoch;
        uint64 maxEpoch;
        bool revoked;
    }

    enum DenialCode {
        NONE,
        SYSTEM_PAUSED,
        ENTITLEMENT_MISSING,
        ENTITLEMENT_REVOKED,
        AGENT_NODE_MISMATCH,
        NOT_CURRENT_DIRECT_OWNER,
        NOT_YET_ACTIVE,
        ENTITLEMENT_EXPIRED,
        OPERATION_DENIED,
        SKILL_MISMATCH,
        SCOPE_MISMATCH,
        POLICY_MISMATCH,
        EPOCH_TOO_OLD,
        EPOCH_TOO_NEW,
        ROOT_NOT_LATEST,
        SKILL_NOT_ACTIVE
    }

    IGoalOSChronicleRegistry public immutable chronicle;
    mapping(bytes32 => Entitlement) public entitlements;

    event EntitlementGranted(
        bytes32 indexed entitlementId,
        bytes32 indexed agentNode,
        bytes32 indexed skillId,
        uint256 operations,
        bytes32 scopeHash,
        uint64 notBefore,
        uint64 expiresAt
    );
    event EntitlementRevoked(bytes32 indexed entitlementId, bytes32 reasonHash);

    error InvalidEntitlement();
    error EntitlementAlreadyExists();

    constructor(
        address ensRegistry,
        bytes32 agentParentNode,
        address chronicleRegistry,
        address admin
    ) GoalOSDirectAgentAuthorizer(ensRegistry, agentParentNode, admin) {
        if (chronicleRegistry == address(0)) revert InvalidEntitlement();
        chronicle = IGoalOSChronicleRegistry(chronicleRegistry);
        _grantRole(ENTITLEMENT_ADMIN_ROLE, admin);
        _grantRole(EMERGENCY_ROLE, admin);
    }

    function pause() external onlyRole(EMERGENCY_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }

    function computeEntitlementId(bytes32 agentNode, bytes32 skillId, bytes32 scopeHash, bytes32 policyHash) public pure returns (bytes32) {
        return keccak256(abi.encode(ENTITLEMENT_DOMAIN, agentNode, skillId, scopeHash, policyHash));
    }

    function grantEntitlement(
        bytes32 labelhash,
        bytes32 skillId,
        bytes32 scopeHash,
        bytes32 policyHash,
        uint256 operations,
        uint64 notBefore,
        uint64 expiresAt,
        uint64 minEpoch,
        uint64 maxEpoch
    ) external onlyRole(ENTITLEMENT_ADMIN_ROLE) whenNotPaused returns (bytes32 entitlementId) {
        if (
            skillId == bytes32(0) || scopeHash == bytes32(0) ||
            policyHash == bytes32(0) || operations == 0 || (expiresAt != 0 && expiresAt <= notBefore) ||
            (maxEpoch != 0 && maxEpoch < minEpoch)
        ) revert InvalidEntitlement();
        bytes32 agentNode = directAgentNode(labelhash);
        entitlementId = computeEntitlementId(agentNode, skillId, scopeHash, policyHash);
        if (entitlements[entitlementId].agentNode != bytes32(0)) revert EntitlementAlreadyExists();
        entitlements[entitlementId] = Entitlement({
            agentNode: agentNode,
            skillId: skillId,
            scopeHash: scopeHash,
            policyHash: policyHash,
            operations: operations,
            notBefore: notBefore,
            expiresAt: expiresAt,
            minEpoch: minEpoch,
            maxEpoch: maxEpoch,
            revoked: false
        });
        emit EntitlementGranted(entitlementId, agentNode, skillId, operations, scopeHash, notBefore, expiresAt);
    }

    function revokeEntitlement(bytes32 entitlementId, bytes32 reasonHash)
        external
        onlyRole(ENTITLEMENT_ADMIN_ROLE)
    {
        Entitlement storage entitlement = entitlements[entitlementId];
        if (entitlement.agentNode == bytes32(0)) revert InvalidEntitlement();
        entitlement.revoked = true;
        emit EntitlementRevoked(entitlementId, reasonHash);
    }

    function authorizationCode(
        bytes32 entitlementId,
        bytes32 labelhash,
        address claimant,
        bytes32 skillId,
        uint256 operation,
        bytes32 requiredScopeHash,
        bytes32 expectedRoot
    ) public view returns (DenialCode) {
        if (paused()) return DenialCode.SYSTEM_PAUSED;
        Entitlement storage entitlement = entitlements[entitlementId];
        if (entitlement.agentNode == bytes32(0)) return DenialCode.ENTITLEMENT_MISSING;
        if (entitlement.revoked) return DenialCode.ENTITLEMENT_REVOKED;
        if (entitlement.agentNode != directAgentNode(labelhash)) return DenialCode.AGENT_NODE_MISMATCH;
        if (!isCurrentDirectOwner(labelhash, claimant)) return DenialCode.NOT_CURRENT_DIRECT_OWNER;
        if (block.timestamp < entitlement.notBefore) return DenialCode.NOT_YET_ACTIVE;
        if (entitlement.expiresAt != 0 && block.timestamp >= entitlement.expiresAt) return DenialCode.ENTITLEMENT_EXPIRED;
        if ((entitlement.operations & operation) != operation || operation == 0) return DenialCode.OPERATION_DENIED;
        if (entitlement.skillId != skillId) return DenialCode.SKILL_MISMATCH;
        if (entitlement.scopeHash != requiredScopeHash) return DenialCode.SCOPE_MISMATCH;
        if (entitlement.policyHash != chronicle.currentPolicyHash()) return DenialCode.POLICY_MISMATCH;
        uint64 epoch = chronicle.latestEpoch();
        if (epoch < entitlement.minEpoch) return DenialCode.EPOCH_TOO_OLD;
        if (entitlement.maxEpoch != 0 && epoch > entitlement.maxEpoch) return DenialCode.EPOCH_TOO_NEW;
        if (expectedRoot == bytes32(0) || expectedRoot != chronicle.currentRoot()) return DenialCode.ROOT_NOT_LATEST;
        if (!chronicle.isSkillActive(skillId)) return DenialCode.SKILL_NOT_ACTIVE;
        return DenialCode.NONE;
    }

    function isInvocationAuthorized(
        bytes32 entitlementId,
        bytes32 labelhash,
        address claimant,
        bytes32 skillId,
        uint256 operation,
        bytes32 requiredScopeHash,
        bytes32 expectedRoot
    ) external view returns (bool) {
        return authorizationCode(
            entitlementId,
            labelhash,
            claimant,
            skillId,
            operation,
            requiredScopeHash,
            expectedRoot
        ) == DenialCode.NONE;
    }
}
