# GoalOS Schemas

These schemas describe public manifests, private capsule structure, scoped entitlements, invocation receipts, and graph-root packets. They are open verification formats; they do not grant access to private capability.
