# MONTREAL.AI Operator Control Plane

Open `dist/index.html` from an HTTPS origin. Copy `dist/config.example.js` to `dist/config.js`, then set deployed contract addresses.

The control plane prepares explicit wallet transactions for candidate roots, Chronicle epochs and skills, entitlements, verified outcomes, and approved Name Wrapper governance. Smart-contract roles remain authoritative.

Never place private capsule contents, model credentials, or signing keys in the static operator files.
