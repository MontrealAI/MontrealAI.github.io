# GoalOS Canonical Private Capability Network Ω — v1.0.0

This release packages the open protocol and reference implementation for the canonical private capability network operating beneath MONTREAL.AI's `agent.agi.eth` institutional root.

## Included

- direct ENS agent ownership authorizer;
- candidate graph registry;
- Chronicle canonical authority and verified-outcome gate;
- scoped, revocable entitlement registry;
- same-origin gateway with one-use EIP-712 access;
- protected internal executor;
- static invocation, public verification, and operator interfaces;
- machine-readable schemas and synthetic conformance examples;
- research papers, deployment, threat, incident, and acceptance documentation;
- automated contract, gateway, executor, client, and operator verification;
- deterministic packaging and SHA-256 manifests.

## Status

Source complete, automated release gates passed, deterministic package complete. Live Mainnet acceptance, independent audits, production key ceremony, penetration testing, and incident rehearsal remain required before production activation.
