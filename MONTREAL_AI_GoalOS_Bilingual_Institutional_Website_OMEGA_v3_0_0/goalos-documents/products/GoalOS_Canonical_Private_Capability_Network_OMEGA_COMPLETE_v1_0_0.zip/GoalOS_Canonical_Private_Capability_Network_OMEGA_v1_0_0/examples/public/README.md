# Public synthetic example

The files in this directory are synthetic conformance examples. They are not Chronicle-admitted production capabilities, live Mainnet commitments, customer evidence, or access entitlements.

The single-leaf manifest is suitable for the public browser verifier: its leaf equals its graph root and its Merkle proof is empty.
