# Private capsule template

This directory contains a non-secret template only. It must never be deployed as a real capability. Production capsules must be created inside MONTREAL.AI's protected environment, encrypted with managed keys, and uploaded to the private capsule store. No production key is included in this package.
