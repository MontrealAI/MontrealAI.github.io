# GoalOS Canonical Private Capability Network Ω

This release candidate implements the MONTREAL.AI capability moat as an enforceable authorization and execution system:

> Only the current owner of a direct `*.agent.agi.eth` identity, carrying a valid, scoped, revocable entitlement, may invoke a Chronicle-admitted capability that verifies under the latest canonical root. The private capability is decrypted and executed only inside the MONTREAL.AI protected execution boundary.

## Final law

- No direct name, no identity.
- No current ownership, no write.
- No Chronicle admission, no canonical skill.
- No entitlement, no use.
- No latest-root proof, no reliance.
- No verified outcome, no compounding.

## Components

- `contracts/` — direct-owner candidate-root registry, Chronicle root authority, direct-agent ownership authorizer, scoped entitlement registry, outcome gate, mocks, compiled artifacts, and executable contract tests.
- `gateway/` — same-origin Cloudflare Worker gateway that issues one-use EIP-712 challenges, verifies current ENS ownership and ERC-1271 signatures, checks entitlements, verifies the latest Chronicle root and Merkle proof, and forwards only authorized invocations.
- `executor/` — non-public internal executor that decrypts private capability capsules, optionally calls a MONTREAL.AI private VPC model runtime, filters output, and returns only bounded results and commitments.
- `client/` — static invocation interface and public verifier. They contain no private capability, keys, prompts, model routes, or cross-customer intelligence.
- `operator/` — static MONTREAL.AI transaction control plane for candidate roots, Chronicle, entitlements, outcomes, and wrapper governance; smart-contract roles remain authoritative.
- `schemas/` — machine-readable entitlement, manifest, capsule, access-request, and receipt standards.
- `examples/` — synthetic demonstration assets only. Never deploy the included synthetic capsule template as a production capability.
- `docs/` — normative protocol standard, architecture, deployment, threat model, acceptance, incident, and claim boundaries.

## Deployment status

The code compiles and the included unit/integration tests pass locally. This package is a production-oriented release candidate, not an audited or activated Mainnet deployment. Production designation requires live Mainnet acceptance with controlled direct names, external smart-contract and cryptographic review, private-runtime deployment, key-management review, and incident-response rehearsal.
