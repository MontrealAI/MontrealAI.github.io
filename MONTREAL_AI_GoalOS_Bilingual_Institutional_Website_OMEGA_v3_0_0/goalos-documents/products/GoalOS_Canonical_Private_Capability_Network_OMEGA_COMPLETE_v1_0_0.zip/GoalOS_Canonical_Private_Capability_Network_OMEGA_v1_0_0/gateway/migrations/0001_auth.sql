CREATE TABLE IF NOT EXISTS challenges (id TEXT PRIMARY KEY, payload TEXT NOT NULL, origin TEXT NOT NULL, expires_at INTEGER NOT NULL, used_at INTEGER);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, payload TEXT NOT NULL, expires_at INTEGER NOT NULL, max_uses INTEGER NOT NULL, used_count INTEGER NOT NULL DEFAULT 0, revoked_at INTEGER);
CREATE TABLE IF NOT EXISTS receipts (receipt_id TEXT PRIMARY KEY, created_at INTEGER NOT NULL, agent_node TEXT NOT NULL, skill_id TEXT NOT NULL, entitlement_id TEXT NOT NULL, graph_root TEXT NOT NULL, input_hash TEXT NOT NULL, output_hash TEXT NOT NULL, status TEXT NOT NULL, public_commitment TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rate_limits (bucket TEXT PRIMARY KEY, window_start INTEGER NOT NULL, count INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_challenges_expiry ON challenges(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
