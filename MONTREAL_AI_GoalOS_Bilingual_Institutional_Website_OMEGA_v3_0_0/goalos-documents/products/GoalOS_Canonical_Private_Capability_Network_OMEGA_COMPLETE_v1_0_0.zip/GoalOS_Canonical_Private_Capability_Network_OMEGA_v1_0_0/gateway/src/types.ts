import type { Hex } from "viem";
export type Address = `0x${string}`;
export type Operation = 1 | 2 | 4 | 8 | 16 | 32;
export interface AccessMessage {
  agentNode: Hex; entitlementId: Hex; skillId: Hex; operation: bigint; scopeHash: Hex;
  graphRoot: Hex; policyHash: Hex; inputHash: Hex; originHash: Hex; nonce: Hex;
  issuedAt: bigint; expiresAt: bigint;
}
export interface ChallengeRequest { agentName:string; wallet:Address; skillId:Hex; operation:Operation; scopeHash:Hex; inputHash:Hex; }
export interface ChallengeRecord {
  id:string; agentName:string; label:string; labelhash:Hex; wallet:Address; entitlementId:Hex; skillId:Hex;
  operation:Operation; scopeHash:Hex; graphRoot:Hex; policyHash:Hex; inputHash:Hex; origin:string; originHash:Hex;
  nonce:Hex; issuedAt:number; expiresAt:number;
}
export interface SessionRecord extends ChallengeRecord { agentNode:Hex; maxUses:number; }
export interface InvocationEnvelope {
  requestId:string; agentName:string; agentNode:Hex; wallet:Address; entitlementId:Hex; skillId:Hex;
  operation:Operation; scopeHash:Hex; graphRoot:Hex; policyHash:Hex; capsuleCommitment:Hex;
  handlerId:string; input:unknown; inputHash:Hex; issuedAt:number;
}
export interface InvocationResult { status:"ok"|"blocked"; output?:unknown; outputHash:Hex; blockedReason?:string; evidence?:Record<string,unknown>; }
export interface PublicCapabilityManifest {
  schema:string; leafDomain:string; schemaHash:Hex; leafHash:Hex; skillId:Hex; graphRoot:Hex; scopeHash:Hex; policyHash:Hex;
  operations:number; capsuleCommitment:Hex; handlerId:string; publicManifest:Record<string,unknown>; merkleProof:Hex[];
}
