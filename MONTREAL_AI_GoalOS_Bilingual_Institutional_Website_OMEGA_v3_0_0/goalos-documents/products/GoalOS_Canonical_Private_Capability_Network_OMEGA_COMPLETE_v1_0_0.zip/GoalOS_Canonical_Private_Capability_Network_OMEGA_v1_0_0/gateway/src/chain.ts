import { createPublicClient, getAddress, http, type Hex, type PublicClient } from "viem";
import type { Address } from "./types";
const ensAbi=[{type:"function",name:"owner",stateMutability:"view",inputs:[{name:"node",type:"bytes32"}],outputs:[{name:"owner",type:"address"}]}] as const;
const wrapperAbi=[{type:"function",name:"getData",stateMutability:"view",inputs:[{name:"id",type:"uint256"}],outputs:[{name:"owner",type:"address"},{name:"fuses",type:"uint32"},{name:"expiry",type:"uint64"}]}] as const;
const chronicleAbi=[
  {type:"function",name:"currentRoot",stateMutability:"view",inputs:[],outputs:[{type:"bytes32"}]},
  {type:"function",name:"currentPolicyHash",stateMutability:"view",inputs:[],outputs:[{type:"bytes32"}]},
  {type:"function",name:"latestEpoch",stateMutability:"view",inputs:[],outputs:[{type:"uint64"}]},
  {type:"function",name:"isSkillActive",stateMutability:"view",inputs:[{name:"skillId",type:"bytes32"}],outputs:[{type:"bool"}]}
] as const;
const entitlementAbi=[{type:"function",name:"authorizationCode",stateMutability:"view",inputs:[{name:"entitlementId",type:"bytes32"},{name:"labelhash",type:"bytes32"},{name:"claimant",type:"address"},{name:"skillId",type:"bytes32"},{name:"operation",type:"uint256"},{name:"requiredScopeHash",type:"bytes32"},{name:"expectedRoot",type:"bytes32"}],outputs:[{type:"uint8"}]}] as const;
export const makePublicClient=(rpcUrl:string)=>createPublicClient({transport:http(rpcUrl)});
export async function currentDirectOwner(args:{client:PublicClient;ensRegistry:Address;approvedWrappers:Address[];node:Hex}){
  const registryOwner=getAddress(await args.client.readContract({address:args.ensRegistry,abi:ensAbi,functionName:"owner",args:[args.node]}));
  if(registryOwner==="0x0000000000000000000000000000000000000000") return null;
  const approved=args.approvedWrappers.some((x)=>getAddress(x)===registryOwner);
  if(!approved) return {owner:registryOwner as Address,wrapped:false,expiry:0n};
  try {
    const [owner,,expiry]=await args.client.readContract({address:registryOwner as Address,abi:wrapperAbi,functionName:"getData",args:[BigInt(args.node)]});
    if(getAddress(owner)==="0x0000000000000000000000000000000000000000" || expiry<=BigInt(Math.floor(Date.now()/1000))) return null;
    return {owner:getAddress(owner) as Address,wrapped:true,expiry};
  } catch { return null; }
}
export async function readChronicleState(client:PublicClient,registry:Address,skillId:Hex){
  const [root,policyHash,epoch,active]=await Promise.all([
    client.readContract({address:registry,abi:chronicleAbi,functionName:"currentRoot"}),
    client.readContract({address:registry,abi:chronicleAbi,functionName:"currentPolicyHash"}),
    client.readContract({address:registry,abi:chronicleAbi,functionName:"latestEpoch"}),
    client.readContract({address:registry,abi:chronicleAbi,functionName:"isSkillActive",args:[skillId]})
  ]);
  return {root,policyHash,epoch,active};
}
export async function entitlementAuthorizationCode(args:{client:PublicClient;registry:Address;entitlementId:Hex;labelhash:Hex;claimant:Address;skillId:Hex;operation:number;scopeHash:Hex;root:Hex}){
  const result=await args.client.readContract({address:args.registry,abi:entitlementAbi,functionName:"authorizationCode",args:[args.entitlementId,args.labelhash,args.claimant,args.skillId,BigInt(args.operation),args.scopeHash,args.root]});
  return Number(result);
}
