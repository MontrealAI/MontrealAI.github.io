import { keccak256, stringToHex, type Hex } from "viem";
function canonical(value:unknown):unknown {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") {
    const out:Record<string,unknown>={};
    for (const key of Object.keys(value as Record<string,unknown>).sort()) out[key]=canonical((value as Record<string,unknown>)[key]);
    return out;
  }
  if (typeof value === "bigint") return value.toString();
  return value;
}
export function canonicalJson(value:unknown):string { return JSON.stringify(canonical(value)); }
export function hashJson(value:unknown):Hex { return keccak256(stringToHex(canonicalJson(value))); }
