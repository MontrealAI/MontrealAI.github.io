import { getAddress, hashTypedData, recoverTypedDataAddress, type Hex, type PublicClient } from "viem";
import type { AccessMessage, Address } from "./types";
export const accessTypes={AccessRequest:[
  {name:"agentNode",type:"bytes32"},{name:"entitlementId",type:"bytes32"},{name:"skillId",type:"bytes32"},
  {name:"operation",type:"uint256"},{name:"scopeHash",type:"bytes32"},{name:"graphRoot",type:"bytes32"},
  {name:"policyHash",type:"bytes32"},{name:"inputHash",type:"bytes32"},{name:"originHash",type:"bytes32"},
  {name:"nonce",type:"bytes32"},{name:"issuedAt",type:"uint64"},{name:"expiresAt",type:"uint64"}
]} as const;
export const accessDomain=(chainId:number,verifyingContract:Address)=>({name:"GoalOS Private Capability Access",version:"1",chainId,verifyingContract} as const);
const erc1271Abi=[{type:"function",name:"isValidSignature",stateMutability:"view",inputs:[{name:"hash",type:"bytes32"},{name:"signature",type:"bytes"}],outputs:[{name:"magicValue",type:"bytes4"}]}] as const;
export async function verifyAccessSignature(args:{client:PublicClient;chainId:number;verifyingContract:Address;signer:Address;message:AccessMessage;signature:Hex}):Promise<boolean>{
  const domain=accessDomain(args.chainId,args.verifyingContract);
  try { const recovered=await recoverTypedDataAddress({domain,types:accessTypes,primaryType:"AccessRequest",message:args.message,signature:args.signature}); if(getAddress(recovered)===getAddress(args.signer)) return true; } catch {}
  try {
    const code=await args.client.getBytecode({address:args.signer}); if(!code) return false;
    const digest=hashTypedData({domain,types:accessTypes,primaryType:"AccessRequest",message:args.message});
    const result=await args.client.readContract({address:args.signer,abi:erc1271Abi,functionName:"isValidSignature",args:[digest,args.signature]});
    return result.toLowerCase()==="0x1626ba7e";
  } catch { return false; }
}
