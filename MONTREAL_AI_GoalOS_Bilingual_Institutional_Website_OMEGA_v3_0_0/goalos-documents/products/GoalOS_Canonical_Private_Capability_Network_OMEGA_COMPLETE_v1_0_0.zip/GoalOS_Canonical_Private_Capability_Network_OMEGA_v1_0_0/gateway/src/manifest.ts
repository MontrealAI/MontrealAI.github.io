import { concatHex, keccak256, stringToHex, type Hex } from "viem";
import { canonicalJson } from "./canonical";
import type { PublicCapabilityManifest } from "./types";
function pairHash(a:Hex,b:Hex):Hex { const [lo,hi]=a.toLowerCase()<b.toLowerCase()?[a,b]:[b,a]; return keccak256(concatHex([stringToHex("GoalOSMerkleNodeV2"),lo,hi])); }
export function capabilityLeaf(manifest:PublicCapabilityManifest):Hex { return keccak256(concatHex([stringToHex(`GoalOS:${manifest.leafDomain}:`),manifest.schemaHash,stringToHex(canonicalJson(manifest.publicManifest))])); }
export function verifyManifestObject(manifest:PublicCapabilityManifest,expectedRoot?:Hex):boolean {
  const leaf=capabilityLeaf(manifest); if(leaf.toLowerCase()!==manifest.leafHash.toLowerCase()) return false;
  let computed=leaf; for(const sibling of manifest.merkleProof) computed=pairHash(computed,sibling);
  return computed.toLowerCase()===(expectedRoot||manifest.graphRoot).toLowerCase();
}
export async function loadAndVerifyManifest(bucket:R2Bucket,skillId:Hex,root:Hex):Promise<PublicCapabilityManifest>{
  const object=await bucket.get(`manifests/${skillId.toLowerCase()}.json`); if(!object) throw new Error("Public capability manifest is unavailable.");
  const manifest=await object.json<PublicCapabilityManifest>();
  if(manifest.skillId.toLowerCase()!==skillId.toLowerCase() || manifest.graphRoot.toLowerCase()!==root.toLowerCase()) throw new Error("Manifest identity or root mismatch.");
  if(!verifyManifestObject(manifest,root)) throw new Error("Manifest leaf or Merkle proof is invalid.");
  return manifest;
}
