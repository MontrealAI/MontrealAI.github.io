import { labelhash, namehash, normalize } from "viem/ens";
import type { Hex } from "viem";
export interface DirectAgentIdentity { normalizedName:string; label:string; labelhash:Hex; node:Hex; }
export function parseDirectAgentName(input:string,parentName="agent.agi.eth"):DirectAgentIdentity {
  const parent=normalize(parentName.trim().toLowerCase());
  const normalized=normalize(input.trim().toLowerCase().replace(/\.$/,""));
  const suffix=`.${parent}`;
  if (!normalized.endsWith(suffix)) throw new Error(`Name must be a direct child of ${parent}.`);
  const label=normalized.slice(0,-suffix.length);
  if (!label || label.includes(".")) throw new Error(`Only a direct *.${parent} name is accepted.`);
  return { normalizedName:normalized, label, labelhash:labelhash(label), node:namehash(normalized) };
}
