import { encodeAbiParameters, getAddress, isAddress, keccak256, parseAbiParameters, stringToHex, type Hex } from "viem";
import { makePublicClient, currentDirectOwner, entitlementAuthorizationCode, readChronicleState } from "./chain";
import { accessDomain, accessTypes, verifyAccessSignature } from "./access";
import { parseDirectAgentName } from "./name";
import { hashJson } from "./canonical";
import { loadAndVerifyManifest } from "./manifest";
import type { AccessMessage, Address, ChallengeRecord, ChallengeRequest, InvocationEnvelope, InvocationResult, Operation, SessionRecord } from "./types";

interface ExecutorService {
  invoke(envelope: InvocationEnvelope): Promise<InvocationResult>;
}
interface Env {
  RPC_URL: string;
  SESSION_HMAC_KEY: string;
  CHAIN_ID: string;
  ENS_REGISTRY: Address;
  AGENT_PARENT_NAME: string;
  APPROVED_NAME_WRAPPERS: string;
  ENTITLEMENT_REGISTRY: Address;
  CHRONICLE_REGISTRY: Address;
  ALLOWED_ORIGINS: string;
  SESSION_TTL_SECONDS: string;
  MAX_INPUT_BYTES: string;
  RATE_LIMIT_CHALLENGE_PER_MINUTE: string;
  RATE_LIMIT_SESSION_PER_MINUTE: string;
  RATE_LIMIT_INVOKE_PER_MINUTE: string;
  AUTH_DB: D1Database;
  CAPABILITY_MANIFESTS: R2Bucket;
  EXECUTOR: ExecutorService;
  ASSETS?: Fetcher;
}

const json = (body: unknown, status = 200, headers: HeadersInit = {}) => new Response(JSON.stringify(body, (_key, value) => typeof value === "bigint" ? value.toString() : value), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
});
const now = () => Math.floor(Date.now()/1000);
const randomHex = (bytes = 32): Hex => `0x${[...crypto.getRandomValues(new Uint8Array(bytes))].map((v)=>v.toString(16).padStart(2,"0")).join("")}`;
const randomToken = () => [...crypto.getRandomValues(new Uint8Array(32))].map((v)=>v.toString(16).padStart(2,"0")).join("");
const encoder = new TextEncoder();
const bytesToHex = (bytes: Uint8Array) => [...bytes].map((value)=>value.toString(16).padStart(2,'0')).join('');
const tokenHash = async (token: string, secret: string) => {
  if (!secret || secret.length < 32) throw new Error('SESSION_HMAC_KEY must contain at least 32 characters.');
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(token)));
  return bytesToHex(digest);
};
const parseAllowedOrigins = (env: Env) => new Set(env.ALLOWED_ORIGINS.split(',').map((x)=>x.trim()).filter(Boolean));
const approvedWrappers = (env: Env) => env.APPROVED_NAME_WRAPPERS.split(',').map((x)=>x.trim()).filter(Boolean).map((x)=>getAddress(x) as Address);

function securityHeaders(origin?: string): HeadersInit {
  return {
    "content-security-policy": "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'; object-src 'none'",
    "strict-transport-security": "max-age=63072000; includeSubDomains; preload",
    "cross-origin-opener-policy": "same-origin",
    "cross-origin-resource-policy": "same-origin",
    "x-frame-options": "DENY",
    "x-content-type-options": "nosniff",
    "referrer-policy": "no-referrer",
    "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=()",
    ...(origin ? { "access-control-allow-origin": origin, "access-control-allow-credentials": "true", "vary": "origin" } : {})
  };
}

function assetSecurityHeaders(contentType: string | null): HeadersInit {
  const html = Boolean(contentType?.includes('text/html'));
  return {
    "content-security-policy": "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'",
    "strict-transport-security": "max-age=63072000; includeSubDomains; preload",
    "cross-origin-opener-policy": "same-origin",
    "cross-origin-resource-policy": "same-origin",
    "x-frame-options": "DENY",
    "x-content-type-options": "nosniff",
    "referrer-policy": "no-referrer",
    "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=()",
    "cache-control": html ? "no-store" : "private, max-age=0, must-revalidate"
  };
}

function requestOrigin(request: Request, env: Env): string {
  const origin = request.headers.get('origin') || '';
  if (!parseAllowedOrigins(env).has(origin)) throw new Error('Origin not allowed.');
  return origin;
}

async function readBody<T>(request: Request, env: Env): Promise<T> {
  const contentType = request.headers.get('content-type') || '';
  if (!contentType.toLowerCase().includes('application/json')) throw new Error('Content-Type must be application/json.');
  const maxBytes = Number(env.MAX_INPUT_BYTES || 65536);
  const declared = Number(request.headers.get('content-length') || '0');
  if (declared > maxBytes) throw new Error('Request body too large.');
  const bytes = new Uint8Array(await request.arrayBuffer());
  if (bytes.byteLength > maxBytes) throw new Error('Request body too large.');
  try {
    return JSON.parse(new TextDecoder().decode(bytes)) as T;
  } catch {
    throw new Error('Invalid JSON body.');
  }
}

async function enforceRateLimit(request: Request, env: Env, action: string, limit: number): Promise<void> {
  if (!Number.isFinite(limit) || limit <= 0) return;
  const clientIdentity = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'unknown';
  const bucket = await tokenHash(`rate:${action}:${clientIdentity}`, env.SESSION_HMAC_KEY);
  const windowStart = Math.floor(now() / 60) * 60;
  const row = await env.AUTH_DB.prepare(`
    INSERT INTO rate_limits (bucket, window_start, count)
    VALUES (?, ?, 1)
    ON CONFLICT(bucket) DO UPDATE SET
      count = CASE WHEN rate_limits.window_start = excluded.window_start THEN rate_limits.count + 1 ELSE 1 END,
      window_start = excluded.window_start
    RETURNING count
  `).bind(bucket, windowStart).first<{count:number}>();
  if (!row || Number(row.count) > limit) throw new Error('Too many requests. Try again shortly.');
}

function validateChallengeRequest(value: ChallengeRequest): ChallengeRequest {
  if (!value || typeof value.agentName !== 'string' || !isAddress(value.wallet)) throw new Error('Invalid challenge request.');
  for (const key of ['skillId','scopeHash','inputHash'] as const) {
    if (!/^0x[0-9a-fA-F]{64}$/.test(value[key])) throw new Error(`Invalid ${key}.`);
  }
  if (![1,2,4,8,16,32].includes(value.operation)) throw new Error('Invalid operation.');
  return { ...value, wallet: getAddress(value.wallet) as Address };
}

async function createChallenge(request: Request, env: Env) {
  const origin = requestOrigin(request, env);
  await enforceRateLimit(request, env, 'challenge', Number(env.RATE_LIMIT_CHALLENGE_PER_MINUTE || 20));
  const body = validateChallengeRequest(await readBody<ChallengeRequest>(request, env));
  const identity = parseDirectAgentName(body.agentName, env.AGENT_PARENT_NAME);
  const client = makePublicClient(env.RPC_URL);
  const owner = await currentDirectOwner({ client, ensRegistry: env.ENS_REGISTRY, approvedWrappers: approvedWrappers(env), node: identity.node });
  if (!owner || getAddress(owner.owner) !== getAddress(body.wallet)) throw new Error('Wallet is not the current owner of this direct GoalOS agent identity.');
  const chronicle = await readChronicleState(client, env.CHRONICLE_REGISTRY, body.skillId);
  if (!chronicle.active) throw new Error('Skill is not Chronicle-active.');
  const entitlementDomain = keccak256(stringToHex("GoalOSEntitlementV1"));
  const entitlementId = keccak256(encodeAbiParameters(
    parseAbiParameters("bytes32, bytes32, bytes32, bytes32, bytes32"),
    [entitlementDomain, identity.node, body.skillId, body.scopeHash, chronicle.policyHash]
  ));
  const originHash = keccak256(stringToHex(origin));
  const issuedAt = now();
  const expiresAt = issuedAt + 300;
  const nonce = randomHex();
  const id = crypto.randomUUID();
  const record: ChallengeRecord = {
    id, agentName: identity.normalizedName, label: identity.label, labelhash: identity.labelhash,
    wallet: body.wallet, entitlementId, skillId: body.skillId,
    operation: body.operation, scopeHash: body.scopeHash, graphRoot: chronicle.root,
    policyHash: chronicle.policyHash, inputHash: body.inputHash, origin, originHash, nonce, issuedAt, expiresAt
  };
  await env.AUTH_DB.prepare('INSERT INTO challenges (id,payload,origin,expires_at) VALUES (?,?,?,?)')
    .bind(id, JSON.stringify(record), origin, expiresAt).run();
  const message: AccessMessage = {
    agentNode: identity.node, entitlementId, skillId: body.skillId,
    operation: BigInt(body.operation), scopeHash: body.scopeHash, graphRoot: chronicle.root,
    policyHash: chronicle.policyHash, inputHash: body.inputHash, originHash, nonce,
    issuedAt: BigInt(issuedAt), expiresAt: BigInt(expiresAt)
  };
  return json({
    challengeId: id,
    typedData: { domain: accessDomain(Number(env.CHAIN_ID), env.ENTITLEMENT_REGISTRY), types: accessTypes, primaryType: 'AccessRequest', message },
    expiresAt
  }, 200, securityHeaders(origin));
}

async function createSession(request: Request, env: Env) {
  const origin = requestOrigin(request, env);
  await enforceRateLimit(request, env, 'session', Number(env.RATE_LIMIT_SESSION_PER_MINUTE || 20));
  const body = await readBody<{ challengeId: string; wallet: Address; signature: Hex }>(request, env);
  if (!body?.challengeId || !isAddress(body.wallet) || !/^0x[0-9a-fA-F]+$/.test(body.signature)) throw new Error('Invalid session request.');
  const row = await env.AUTH_DB.prepare('SELECT payload, expires_at, used_at FROM challenges WHERE id=?').bind(body.challengeId).first<{payload:string;expires_at:number;used_at:number|null}>();
  if (!row || row.used_at || row.expires_at < now()) throw new Error('Challenge is missing, expired, or already used.');
  const record = JSON.parse(row.payload) as ChallengeRecord;
  if (record.origin !== origin || getAddress(record.wallet) !== getAddress(body.wallet)) throw new Error('Challenge binding mismatch.');
  const identity = parseDirectAgentName(record.agentName, env.AGENT_PARENT_NAME);
  const client = makePublicClient(env.RPC_URL);
  const message: AccessMessage = {
    agentNode: identity.node, entitlementId: record.entitlementId, skillId: record.skillId,
    operation: BigInt(record.operation), scopeHash: record.scopeHash, graphRoot: record.graphRoot,
    policyHash: record.policyHash, inputHash: record.inputHash, originHash: record.originHash,
    nonce: record.nonce, issuedAt: BigInt(record.issuedAt), expiresAt: BigInt(record.expiresAt)
  };
  if (!await verifyAccessSignature({ client, chainId: Number(env.CHAIN_ID), verifyingContract: env.ENTITLEMENT_REGISTRY, signer: getAddress(body.wallet) as Address, message, signature: body.signature })) {
    throw new Error('Invalid wallet signature.');
  }
  const owner = await currentDirectOwner({ client, ensRegistry: env.ENS_REGISTRY, approvedWrappers: approvedWrappers(env), node: identity.node });
  if (!owner || getAddress(owner.owner) !== getAddress(body.wallet)) throw new Error('Direct agent ownership changed.');
  const chronicle = await readChronicleState(client, env.CHRONICLE_REGISTRY, record.skillId);
  if (!chronicle.active || chronicle.root.toLowerCase() !== record.graphRoot.toLowerCase() || chronicle.policyHash.toLowerCase() !== record.policyHash.toLowerCase()) {
    throw new Error('Chronicle state changed; request a new challenge.');
  }
  const code = await entitlementAuthorizationCode({ client, registry: env.ENTITLEMENT_REGISTRY, entitlementId: record.entitlementId, labelhash: record.labelhash, claimant: getAddress(body.wallet) as Address, skillId: record.skillId, operation: record.operation, scopeHash: record.scopeHash, root: record.graphRoot });
  if (code !== 0) throw new Error(`Entitlement denied with code ${code}.`);
  const manifest = await loadAndVerifyManifest(env.CAPABILITY_MANIFESTS, record.skillId, record.graphRoot);
  if ((manifest.operations & record.operation) !== record.operation || manifest.scopeHash.toLowerCase() !== record.scopeHash.toLowerCase() || manifest.policyHash.toLowerCase() !== record.policyHash.toLowerCase()) {
    throw new Error('Manifest scope or policy does not authorize the requested operation.');
  }
  const consumed = await env.AUTH_DB.prepare('UPDATE challenges SET used_at=? WHERE id=? AND used_at IS NULL AND expires_at>=?').bind(now(), body.challengeId, now()).run();
  if ((consumed.meta.changes || 0) !== 1) throw new Error('Challenge replay detected.');
  const token = randomToken();
  const hash = await tokenHash(token, env.SESSION_HMAC_KEY);
  const ttl = Math.min(Number(env.SESSION_TTL_SECONDS || 300), 600);
  const session: SessionRecord = { ...record, agentNode: identity.node, maxUses: 1, expiresAt: now() + ttl };
  await env.AUTH_DB.prepare('INSERT INTO sessions (token_hash,payload,expires_at,max_uses,used_count) VALUES (?,?,?,?,0)')
    .bind(hash, JSON.stringify(session), session.expiresAt, session.maxUses).run();
  return json({ ok: true, agentName: record.agentName, skillId: record.skillId, graphRoot: record.graphRoot, expiresAt: session.expiresAt }, 200, {
    ...securityHeaders(origin),
    'set-cookie': `__Host-goalos_cap=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${ttl}`
  });
}

function cookie(request: Request, name: string): string | null {
  const header = request.headers.get('cookie') || '';
  for (const part of header.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return rest.join('=');
  }
  return null;
}

async function invoke(request: Request, env: Env) {
  const origin = requestOrigin(request, env);
  await enforceRateLimit(request, env, 'invoke', Number(env.RATE_LIMIT_INVOKE_PER_MINUTE || 60));
  const token = cookie(request, '__Host-goalos_cap') || request.headers.get('authorization')?.replace(/^Bearer\s+/i,'');
  if (!token) throw new Error('Missing protected capability session.');
  const hash = await tokenHash(token, env.SESSION_HMAC_KEY);
  const row = await env.AUTH_DB.prepare('SELECT payload,expires_at,max_uses,used_count,revoked_at FROM sessions WHERE token_hash=?').bind(hash).first<{payload:string;expires_at:number;max_uses:number;used_count:number;revoked_at:number|null}>();
  if (!row || row.revoked_at || row.expires_at < now() || row.used_count >= row.max_uses) throw new Error('Session expired, revoked, or exhausted.');
  const session = JSON.parse(row.payload) as SessionRecord;
  if (session.origin !== origin) throw new Error('Session origin mismatch.');
  const body = await readBody<{ input: unknown }>(request, env);
  if (hashJson(body.input).toLowerCase() !== session.inputHash.toLowerCase()) throw new Error('Invocation input does not match the signed request.');
  const client = makePublicClient(env.RPC_URL);
  const identity = parseDirectAgentName(session.agentName, env.AGENT_PARENT_NAME);
  const owner = await currentDirectOwner({ client, ensRegistry: env.ENS_REGISTRY, approvedWrappers: approvedWrappers(env), node: identity.node });
  if (!owner || getAddress(owner.owner) !== getAddress(session.wallet)) throw new Error('Current direct agent ownership is no longer valid.');
  const chronicle = await readChronicleState(client, env.CHRONICLE_REGISTRY, session.skillId);
  if (!chronicle.active || chronicle.root.toLowerCase() !== session.graphRoot.toLowerCase()) throw new Error('Latest Chronicle root no longer authorizes this capability.');
  const code = await entitlementAuthorizationCode({ client, registry: env.ENTITLEMENT_REGISTRY, entitlementId: session.entitlementId, labelhash: session.labelhash, claimant: session.wallet, skillId: session.skillId, operation: session.operation, scopeHash: session.scopeHash, root: chronicle.root });
  if (code !== 0) throw new Error(`Entitlement was revoked or changed; code ${code}.`);
  const manifest = await loadAndVerifyManifest(env.CAPABILITY_MANIFESTS, session.skillId, chronicle.root);
  if ((manifest.operations & session.operation) !== session.operation || manifest.scopeHash.toLowerCase() !== session.scopeHash.toLowerCase() || manifest.policyHash.toLowerCase() !== chronicle.policyHash.toLowerCase()) {
    throw new Error('Latest manifest no longer authorizes this operation or scope.');
  }
  const spent = await env.AUTH_DB.prepare('UPDATE sessions SET used_count=used_count+1 WHERE token_hash=? AND revoked_at IS NULL AND expires_at>=? AND used_count<max_uses').bind(hash, now()).run();
  if ((spent.meta.changes || 0) !== 1) throw new Error('Session replay detected.');
  const envelope: InvocationEnvelope = {
    requestId: crypto.randomUUID(), agentName: session.agentName, agentNode: session.agentNode, wallet: session.wallet,
    entitlementId: session.entitlementId, skillId: session.skillId, operation: session.operation, scopeHash: session.scopeHash,
    graphRoot: chronicle.root, policyHash: chronicle.policyHash, capsuleCommitment: manifest.capsuleCommitment,
    handlerId: manifest.handlerId, input: body.input, inputHash: session.inputHash, issuedAt: now()
  };
  const result = await env.EXECUTOR.invoke(envelope);
  const receiptId = crypto.randomUUID();
  const publicCommitment = keccak256(stringToHex(JSON.stringify({ receiptId, agentNode: envelope.agentNode, skillId: envelope.skillId, graphRoot: envelope.graphRoot, inputHash: envelope.inputHash, outputHash: result.outputHash, status: result.status })));
  await env.AUTH_DB.prepare('INSERT INTO receipts (receipt_id,created_at,agent_node,skill_id,entitlement_id,graph_root,input_hash,output_hash,status,public_commitment) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .bind(receiptId, now(), envelope.agentNode, envelope.skillId, envelope.entitlementId, envelope.graphRoot, envelope.inputHash, result.outputHash, result.status, publicCommitment).run();
  return json({ ...result, receipt: { receiptId, publicCommitment, graphRoot: envelope.graphRoot } }, result.status === 'ok' ? 200 : 403, securityHeaders(origin));
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const origin = request.headers.get('origin') || undefined;
    if (request.method === 'OPTIONS') {
      try {
        const allowedOrigin = requestOrigin(request, env);
        return new Response(null, { status: 204, headers: { ...securityHeaders(allowedOrigin), 'access-control-allow-methods': 'POST,OPTIONS', 'access-control-allow-headers': 'content-type,authorization' } });
      } catch {
        return json({ error: 'Origin not allowed.' }, 403, securityHeaders());
      }
    }
    try {
      if (request.method === 'POST' && url.pathname === '/v1/challenge') return await createChallenge(request, env);
      if (request.method === 'POST' && url.pathname === '/v1/session') return await createSession(request, env);
      if (request.method === 'POST' && url.pathname === '/v1/invoke') return await invoke(request, env);
      if (request.method === 'GET' && url.pathname === '/health') return json({ status: 'operational', privateCapabilityPayloadsExposed: false }, 200, securityHeaders(origin));
      if (request.method === 'GET' && env.ASSETS) {
        const asset = await env.ASSETS.fetch(request);
        const headers = new Headers(asset.headers);
        for (const [key,value] of Object.entries(assetSecurityHeaders(headers.get('content-type')))) headers.set(key, String(value));
        return new Response(asset.body, { status: asset.status, statusText: asset.statusText, headers });
      }
      return json({ error: 'Not found' }, 404, securityHeaders(origin));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Request failed.';
      return json({ error: message }, 400, securityHeaders(origin));
    }
  }
};
