# GoalOS Capability Gateway

The gateway issues origin-bound, one-use EIP-712 challenges; verifies current direct ENS ownership, EOA or ERC-1271 signatures, Chronicle state, entitlement, public manifest, and latest-root proof; then invokes the internal executor through a service binding.

```bash
npm install
npm run verify
npm run dry-run
```

Copy `wrangler.production.example.toml` to `wrangler.production.toml`, replace every placeholder, configure secrets and bindings, run the root production preflight, then deploy through an environment-protected workflow.
