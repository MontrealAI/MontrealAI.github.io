---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## **MONTRÉAL.AI EVENTS**

### **Salon | Press Dinner | Concert | Art Auction | Charity Gala**

![Montréal.AI Events](../images/QuebecAIv6WhatIsAI1440x1440.jpg "Montréal.AI Events")

## **❖ MONTREAL.AI World-Class Events**

### _**AI DEBATE 2 : MARK YOUR CALENDAR — Details To Be Announced!**_

[![MONTREAL.AI World-Class Events | AI DEBATE 2 : MARK YOUR CALENDAR — Details To Be Announced!](../images/aidebatetwo2560v0.jpg "MONTREAL.AI World-Class Events | AI DEBATE 2 : MARK YOUR CALENDAR — Details To Be Announced!")](https://aidebate.eventbrite.ca)

**This Is The Debate The AI World Has Been Waiting For**

### Tickets and Group Reservation

LIVE STREAMING : https://aidebate.eventbrite.ca

__Date and Time:__ Wednesday, December 23, 2020 | 5:00 PM to 8:00 PM EST

***

### _(**Previous Event**) AI DEBATE 1 : Yoshua Bengio | Gary Marcus_

[![MONTREAL.AI World-Class Events — AI DEBATE 1 : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "MONTREAL.AI World-Class Events — AI DEBATE 1 : Yoshua Bengio | Gary Marcus")](https://montrealartificialintelligence.com/aidebate/)

At Mila in Montreal, on Monday, December 23, 2019, from 6:30 PM to 8:30 PM (EST), Gary Marcus and Yoshua Bengio debated on the best way forward for AI. ZDNet described the event organized by MONTREAL.AI as a [“Historic Event”](https://www.zdnet.com/article/devils-in-the-details-in-bengio-marcus-ai-debate/). 5,225 tickets were RSVP’d for the live event. [Report on the AI Debate](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/).

**Slides, video, readings** and more can be found on the **MONTREAL.AI** debate [webpage](https://montrealartificialintelligence.com/aidebate/).

**MONTREAL.AI** is grateful to [Gary Marcus](http://garymarcus.com), [Yoshua Bengio](https://mila.quebec/en/yoshua-bengio/), [Mila - Institut Québécois d'Intelligence Artificielle](https://mila.quebec/) and to the collaborative [Montreal AI ecosystem](https://www.facebook.com/groups/MontrealAI/). A special thanks to [Sasha Lu](https://sashaluccioni.com).

[![100 countries and 1,000 cities](../images/attendeescity.jpeg "100 countries and 1,000 cities")](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/)

***

## **❖ QUEBEC AI SYMPOSIUM**

### _Stimulating the Economic Activity, Research and Innovation in AI in Quebec_

[![QUEBEC AI SYMPOSIUM — Stimulating the Economic Activity, Research and Innovation in AI in Quebec](../images/quebecaisymposium.png "QUEBEC AI SYMPOSIUM — Stimulating the Economic Activity, Research and Innovation in AI in Quebec")](https://quebecaisymposium.eventbrite.ca)

The **QUEBEC AI SYMPOSIUM**, administered by [MONTREAL.AI](http://www.montreal.ai) and [QUEBEC.AI](http://www.quebec.ai), is an event to stimulate the economic activity, research and innovation in artificial intelligence in Quebec and thus contribute to the competitiveness and influence of Quebec nationally and internationally.

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://quebecaisymposium.eventbrite.ca

__Date And Time:__ __Wed, October 7, 2020 | 9:30 AM – 8:30 PM EDT__.
__Location: Details To Be Announced__.

__Website:__ http://quebecaisymposium.com.

***

## **❖ Chief AI Officers : C-level AI**

### _Executive Education‎_

__*Chief AI Officers : C-level AI*__ harnesses the fundamentals of artificial intelligence on a truly global scale and put them to strategically leverage enterprises, governments and institutions with precision engineering.

[![Chief AI Officers : C-level AI | Executive Education‎](../images/ExecutiveEducation‎.jpg "Chief AI Officers : C-level AI | Executive Education‎")](https://chiefaiofficers.eventbrite.ca)
<a href="https://chiefaiofficers.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Chief AI Officers : C-level AI | Ticket</a>
> "**_In a moment of technological disruption, leadership matters._**" — Andrew Ng

__Success is about actively shaping the game that matters to you.__ This well-crafted C-level professional keynote pioneers a highly impactful understanding of [_transformative artificial intelligence_](https://www.openphilanthropy.org/blog/some-background-our-views-regarding-advanced-artificial-intelligence#Sec1) strategies, at boardroom level, bringing to life new perspectives for state, national, and international organizations.

### Participant Profile
{% pullquote [CSS class] %}
"**_We want to see more life-long learning opportunities, across the board matrix interoperability and the development of Chief AI Officers who possess the knowledges, the skills and the competencies to orchestrate impactful breakthroughs and tangible economic growth for Fortune 500, governments and interagency partners in full compliance with our masterplan : The Montréal AI-First Conglomerate Overarching Program._**" — Vincent Boucher, B. Sc. Physics, M. A. Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI
{% endpullquote %}
__*Chief AI Officers : C-level AI*__  is designed for the : 

- Board Members;
- Captains of Industry;
- Chancellors;
- Chief Executive Officers;
- Commanders;
- Excellences;
- Global Chairs
- High-Potential Executives;
- Iconic Tech Entrepreneurs;
- Luminaries;
- Managing Directors;
- Moguls;
- Philanthropists;
- Presidents;
- Scholars;
- Successful Entrepreneurs and Financiers; and
- Visionary Founders

... who wish to strategically unleash the power of artificial intelligence on a truly global scale.

> "**_Breakthrough in machine learning would be worth 10 Microsofts._**" — Bill Gates

<div id="eventbrite-widget-container-106581813072"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '106581813072',
        iframeContainerId: 'eventbrite-widget-container-106581813072',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Location: This is an online event.__

***

## **❖ MONTREAL.AI Captains of AI Industries Celebration**

### _Honoring Award-Winning Captains of AI Industries & Luminaries_

***

## **❖ Artificial Intelligence 101 | International Webinar**

### _Pioneering an Impactful Understanding of AI_

For the newcomers to artificial intelligence, the __General Secretariat of MONTREAL.AI__ introduces, with authority and insider knowledge: "__*AI 101 Webinar*__: *The First World-Class Overview of AI for the General Public*".

__Location: This is an online event.__

[![ARTIFICIAL INTELLIGENCE 101 | WEBINAR](../images/academy1920cover_v0.jpg "ARTIFICIAL INTELLIGENCE 101 | WEBINAR")](https://ai101webinar.eventbrite.ca)

__AI opens up a world of new possibilities.__ This __AI 101 Webinar__ harnesses the fundamentals of artificial intelligence for the purpose of providing participants with powerful AI tools to *__learn__*, *__deploy__* and *__scale AI__*.

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

__Program overview and tickets:__ https://ai101webinar.eventbrite.ca

<div id="eventbrite-widget-container-108495003476"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '108495003476',
        iframeContainerId: 'eventbrite-widget-container-108495003476',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

***

## **❖ MONTREAL.AI Press Dinner**

### _Honoring Award-Winning AI Journalism_

***

## **❖ MONTREAL.AI's Fine Arts Auction**

### _Unveilling a World of Hidden Secrets..._

![MONTREAL.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...](../images/AITrillion1440.jpg "MONTREAL.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...")

On October 25, 2018, [the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Today, the _House of Montréal.AI Fine Arts_ introduces : _Montréal.AI's Fine Arts Auction_, the **first international auction dedicated to quintessential fine AI arts**.

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Montréal.AI Fine Arts

We are getting ready for the first auction. Top art collectors will be able to place bids internationally.

***

## **❖ MONTREAL.AI Salon**

### _Gathering of People Under the Roof of an Inspiring Host_

***

## **❖ MONTREAL.AI's Fireside Chat**

***

## **❖ MONTREAL.AI MIXER**

### _Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem_

[![MONTREAL.AI MIXER — Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem.](../images/MontrealAIMixerv2.jpg "MONTREAL.AI MIXER — Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem.")](https://aimixer.eventbrite.ca)

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://aimixer.eventbrite.ca

__Date And Time:__ __Thu, 10 June 2021 | 5:30 PM – 7:30 PM EDT__.
__Location: Details To Be Announced__.

***

## **❖ MONTREAL.AI's Ambassadors Dinner**

***

## **❖ Deep Reinforcement Learning with OpenAI Gym 101 (Webinar)**

### _AI Agents Learning from Experience, for All_

__MONTREAL.AI__ introduces: "__*Deep Reinforcement Learning with OpenAI Gym 101*__".

__Location: This is an online event.__

[![DEEP REINFORCEMENT LEARNING WITH OPENAI GYM 101 | WEBINAR](../images/RL101Webinarv5.jpg "DEEP REINFORCEMENT LEARNING WITH OPENAI GYM 101 | WEBINAR")](https://reinforcementlearning101.eventbrite.ca)

AI is capable of profoundly transforming industries and societies. Autonomous agents will play a central role.

> "**_Intelligence is the computational part of the ability to predict and control a stream of experience._**" — Rich Sutton

__Program overview and tickets:__ https://reinforcementlearning101.eventbrite.ca

<div id="eventbrite-widget-container-99894922402"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '99894922402',
        iframeContainerId: 'eventbrite-widget-container-99894922402',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

***

## **❖ MONTREAL.AI Orchestra**

### _Pioneering Superhuman Symphonies_

[![MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies](../images/AIConcert1440x2880v2.jpg "MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ MONTREAL.AI Philanthropic Award Gala**

> "**_It's springtime for AI, and we're anticipating a long summer._**" — Bill Braun, CIO of Chevron

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*

#__AIFirst__ #__Chief AI Officers__ #__MontrealAI__ #__MontrealArtificialIntelligence__
