---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## **MONTRÉAL.AI EVENTS**

### **Salon | Press Dinner | Concert | Art Auction | Charity Gala**

![Montréal.AI Events](../images/QuebecAIv6WhatIsAI1440x1440.jpg "Montréal.AI Events")

## **❖ MONTREAL.AI World-Class Events**

### _SEMINAL DEBATE : Yoshua Bengio | Gary Marcus_

[![MONTREAL.AI World-Class Events — SEMINAL DEBATE : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "MONTREAL.AI World-Class Events — SEMINAL DEBATE : Yoshua Bengio | Gary Marcus")](https://bengio-marcus.eventbrite.ca)

**This Is The Debate The AI World Has Been Waiting For**

Date and Time : December 23, 2019 | 6:30 PM – 8:30 PM EST

LIVE STREAMING : https://bengio-marcus.eventbrite.ca

<div id="eventbrite-widget-container-81620778947"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '81620778947',
        iframeContainerId: 'eventbrite-widget-container-81620778947',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

**MONTREAL.AI** is grateful to **Mila - Institut Québécois d'Intelligence Artificielle** and to the collaborative Montreal AI ecosystem. A special thanks to Sasha Lu for her decisive involvement.

***

## **❖ MONTREAL.AI Captains of AI Industries Celebration**

### _Honoring Award-Winning Captains of AI Industries & Luminaries_

***
## **❖ Artificial Intelligence 101 | International Webinar**

### _A Well-Crafted Actionable 75 Minutes Tutorial_

Encompassing all facets of AI, the __General Secretariat of MONTREAL.AI__ introduces, with authority and insider knowledge: "__*AI 101 Webinar*__: *The First World-Class Overview of AI for the General Public*".

__Location: This is an online event.__

[![ARTIFICIAL INTELLIGENCE 101 - INTERNATIONAL WEBINAR](../images/AI101Webinar2560v2.jpg "ARTIFICIAL INTELLIGENCE 101 - INTERNATIONAL WEBINAR")](https://ai101webinar.eventbrite.ca)

<a href="https://www.eventbrite.ca/e/artificial-intelligence-101-international-webinar-tickets-65144278290?ref=ebtn" target="_blank"><img src="https://www.eventbrite.ca/custombutton?eid=54093711748" alt="Eventbrite - ARTIFICIAL INTELLIGENCE 101 INTERNATIONAL WEBINAR" /></a>

__AI opens up a world of new possibilities.__ This __AI 101 Webinar__ harnesses the fundamentals of artificial intelligence for the purpose of providing participants with powerful AI tools to *__learn__*, *__deploy__* and *__scale AI__*.

__Program overview and tickets:__ https://ai101webinar.eventbrite.ca

<div id="eventbrite-widget-container-65144278290"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '65144278290',
        iframeContainerId: 'eventbrite-widget-container-65144278290',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

***

## **❖ MONTREAL.AI Press Dinner**

### _Honoring Award-Winning AI Journalism_

***

## **❖ MONTREAL.AI's Fine Arts Auction**

### _Unveilling a World of Hidden Secrets..._

![MONTREAL.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...](../images/AITrillion1440.jpg "MONTREAL.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...")

On October 25, 2018, [the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Today, the _House of Montréal.AI Fine Arts_ introduces : _Montréal.AI's Fine Arts Auction_, the **first international auction dedicated to quintessential fine AI arts**.

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Montréal.AI Fine Arts

We are getting ready for the first auction. Top art collectors will be able to place bids internationally.

***

## **❖ MONTREAL.AI Salon**

### _Gathering of People Under the Roof of an Inspiring Host_

***

## **❖ MONTREAL.AI Academy : AI 101**

### _Pioneering an Impactful Understanding of AI_

### **AI 101: For the Newcomers to Artificial Intelligence!**

On **Wed, March 11, 2020 | 2:30 PM – 4:00 PM EDT**, the __General Secretariat of MONTREAL.AI__ will present, with authority: "__*Artificial Intelligence 101: The First World-Class Overview of AI for the General Public*__".

__Location: NRH Prince Arthur - Ballroom, 3625 Avenue du Parc, Montreal (Québec), Canada, H2X 3P8.__
<!-- Noscript content for added SEO -->
<noscript><a href="https://artificialintelligence101.eventbrite.ca" rel="noopener noreferrer" target="_blank"></noscript>
<!-- You can customize this button any way you like -->
<button id="eventbrite-widget-modal-trigger-80169451989" type="button">Artificial Intelligence 101 : Buy Tickets on Eventbrite</button>
<noscript></a>Buy Tickets on Eventbrite</noscript>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        widgetType: 'checkout',
        eventId: '80169451989',
        modal: true,
        modalTriggerElementId: 'eventbrite-widget-modal-trigger-80169451989',
        onOrderComplete: exampleCallback
    });
</script>

[![Artificial Intelligence 101: The First World-Class Overview of AI for the General Public](../images/InvitationLetter11March2020v31920.jpg "Artificial Intelligence 101: The First World-Class Overview of AI for the General Public")](https://artificialintelligence101.eventbrite.ca)

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://artificialintelligence101.eventbrite.ca

__Language:__ Tutorial given in __English__.
__Date And Time:__ __Wed, March 11, 2020 | 2:30 PM – 4:00 PM EDT__.
__Location: NRH Prince Arthur - Ballroom, 3625 Avenue du Parc, Montreal (Québec), Canada, H2X 3P8__.

<div id="eventbrite-widget-container-80169451989"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '80169451989',
        iframeContainerId: 'eventbrite-widget-container-80169451989',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ MONTREAL.AI's Fireside Chat**

***

## **❖ MONTREAL.AI's Ambassadors Dinner**

***

## **❖ MONTREAL.AI Orchestra**

### _Pioneering Superhuman Symphonies_

[![MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies](../images/AIConcert1440x2880v2.jpg "MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ MONTREAL.AI Philanthropic Award Gala**

> "**_It's springtime for AI, and we're anticipating a long summer._**" — Bill Braun, CIO of Chevron

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*

#__AIFirst__ #__Chief AI Officers__ #__MontrealAI__ #__MontrealArtificialIntelligence__
