# Evidence and reproducibility companion - Version 6.0.0

This companion supports the synthetic evidence layer of the unified paper. It contains:

- the current Evidence Dossier;
- the complete disclosed Aurelia synthetic cycle summaries;
- GSSB-4 source code, generated cases, environment cards, case-level results, figures and benchmark manifest;
- the paper sections that interpret those evidence objects.

All results are synthetic, deterministic and unaudited. They demonstrate reproducible institutional mechanics; they do not establish real-world Specialist ASI or production authority.

Rebuild GSSB-4 from this directory:

```bash
python gssb4/run_gssb4.py --out gssb4/rebuild
```
