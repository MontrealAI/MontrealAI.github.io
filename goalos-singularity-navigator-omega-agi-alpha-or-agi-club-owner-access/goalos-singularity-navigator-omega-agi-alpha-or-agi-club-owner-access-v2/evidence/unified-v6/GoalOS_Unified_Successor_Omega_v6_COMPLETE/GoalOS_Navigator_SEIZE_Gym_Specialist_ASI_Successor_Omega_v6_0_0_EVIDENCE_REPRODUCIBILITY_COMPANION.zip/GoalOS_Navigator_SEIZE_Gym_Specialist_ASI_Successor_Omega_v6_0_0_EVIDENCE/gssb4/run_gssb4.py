from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

VERSION='3.0.0'; BENCHMARK='GSSB-4-v3.0.0'; SEED=30082026
MISSIONS={
 'invoice_integrity':('Invoice Integrity',0.00,1.00,12.0,0.14),
 'building_operations':('Building Operations',0.10,1.15,16.0,0.18),
 'acquisition_underwriting':('Acquisition Underwriting',0.18,1.35,28.0,0.20),
 'verified_software_engineering':('Verified Software Engineering',0.06,1.10,18.0,0.14),
}
SPLITS={'formation':800,'proof':500,'transfer':200}
# label, base logit, evidence, reliability, governance, sovereignty, transfer, human factor, cost factor, critical guard, adversarial resilience, shift resilience, unauthorized rate
P={
 'incumbent':('Incumbent',1.05,.82,.86,.94,.72,.76,1.00,1.00,.80,.72,.70,0.0),
 'general_ai_copilot':('General AI Copilot',1.15,.76,.79,.72,.50,.68,.62,.62,.62,.58,.54,.004),
 'specialist_cell':('Specialist Cell',1.72,.92,.90,.88,.76,.84,.54,.82,.90,.84,.80,.001),
 'sovereign_hybrid':('Sovereign Hybrid',2.08,.975,.95,.97,.95,.91,.39,.78,.975,.94,.91,0.0),
 'recursive_successor_omega':('Recursive Successor Ω',2.45,.992,.98,.987,.975,.96,.33,.74,1.0,.97,.96,0.0),
}
ADJ={
 'invoice_integrity':{'incumbent':.05,'general_ai_copilot':-.02,'specialist_cell':.08,'sovereign_hybrid':.12,'recursive_successor_omega':.16},
 'building_operations':{'incumbent':-.02,'general_ai_copilot':-.10,'specialist_cell':.00,'sovereign_hybrid':.05,'recursive_successor_omega':.12},
 'acquisition_underwriting':{'incumbent':.08,'general_ai_copilot':-.15,'specialist_cell':-.04,'sovereign_hybrid':-.02,'recursive_successor_omega':.10},
 'verified_software_engineering':{'incumbent':-.02,'general_ai_copilot':.03,'specialist_cell':.10,'sovereign_hybrid':.08,'recursive_successor_omega':.13},
}
G={'lcb':.20,'evidence':.95,'reliability':.90,'governance':.95,'transfer':.88,'critical':0,'unauthorized':0}

def sigmoid(x): return 1/(1+np.exp(-x))
def filehash(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def cases(mission,split,n,seed):
 label,shift0,valscale,human,cr=MISSIONS[mission]; r=np.random.default_rng(seed)
 d=np.clip(r.beta(2.1,2.4,n)+shift0,0,1); er=np.clip(r.beta(3.6,1.7,n),0,1); adv=(r.random(n)<(.10 if split!='transfer' else .23)).astype(int); shift=np.clip(r.beta(1.4,5,n)+(0.22 if split=='transfer' else 0),0,1); amb=np.clip(r.beta(2,2.2,n)+.16*adv,0,1); crit=(r.random(n)<cr*(.65+.7*d)).astype(int); hidden=(r.random(n)<(.12+.18*d+.12*shift)).astype(int); value=valscale*(.55+1.9*r.random(n))*(1+1.5*crit)
 return pd.DataFrame({'benchmark_id':BENCHMARK,'mission':mission,'mission_label':label,'split':split,'case_id':[f'{mission}-{split}-{i:05d}' for i in range(n)],'difficulty':d,'evidence_richness':er,'adversarial':adv,'distribution_shift':shift,'ambiguity':amb,'critical':crit,'hidden_dependency':hidden,'mission_value':value})

def eval_candidate(c,cand,seed):
 label,base,ev,rel,gov,sov,trans,hf,cf,cguard,ares,sres,ur=P[cand]; r=np.random.default_rng(seed); m=c.mission.iloc[0]
 score=base+ADJ[m][cand]-1.75*c.difficulty-.72*c.ambiguity-.58*c.adversarial*(1-ares)-.75*c.distribution_shift*(1-sres)-.25*c.hidden_dependency*(1-ev)+.22*c.evidence_richness
 correct=(r.random(len(c))<np.clip(sigmoid(score),.05,.997)).astype(int); evidence=(r.random(len(c))<np.clip(ev+.014*c.evidence_richness-.012*c.ambiguity-.008*c.distribution_shift,.05,.999)).astype(int); miss=((c.critical==1)&(correct==0)&(r.random(len(c))<np.clip((1-cguard)*(.5+.4*c.difficulty),0,1))).astype(int); unauth=(r.random(len(c))<ur*(.7+.6*c.adversarial)).astype(int)
 human=MISSIONS[m][2]*hf*(.72+.58*c.difficulty+.22*c.ambiguity); cost=cf*(.78+.62*c.difficulty+.14*c.adversarial); latency=(5.8+MISSIONS[m][2]*.22)*hf*(.70+.50*c.difficulty); reliability=np.clip(rel-.07*c.difficulty-.045*c.distribution_shift-.025*c.adversarial+.04*correct,0,1); governance=np.clip(gov-.14*unauth-.025*(1-evidence),0,1); transfer=np.clip(trans-.16*c.distribution_shift*(1-sres)-.025*c.adversarial,0,1); sovereignty=np.clip(sov-.03*c.hidden_dependency,0,1); accepted=c.mission_value*np.where(correct==1,1,-.65)*(.90+.10*evidence); utility=accepted-(.03*human+.18*cost+.16*latency)-4.5*miss-1.7*unauth-.45*(1-evidence)-.45*(1-governance)+.30*sovereignty+.25*transfer
 o=c[['benchmark_id','mission','mission_label','split','case_id','critical']].copy(); o['candidate']=cand; o['candidate_label']=label; o['correct']=correct; o['evidence_complete']=evidence; o['critical_miss']=miss; o['unauthorized_action']=unauth; o['human_minutes']=human; o['direct_cost']=cost; o['latency']=latency; o['reliability']=reliability; o['governance']=governance; o['transfer']=transfer; o['sovereignty']=sovereignty; o['mission_utility']=utility
 return o

def summary(e):
 a=e.groupby(['mission','mission_label','split','candidate','candidate_label'],as_index=False).agg(n_cases=('case_id','count'),decision_accuracy=('correct','mean'),evidence_coverage=('evidence_complete','mean'),critical_misses=('critical_miss','sum'),unauthorized_actions=('unauthorized_action','sum'),human_minutes=('human_minutes','mean'),direct_cost=('direct_cost','mean'),latency=('latency','mean'),reliability=('reliability','mean'),governance=('governance','mean'),transfer=('transfer','mean'),sovereignty=('sovereignty','mean'),mission_utility=('mission_utility','mean'))
 return a

def paired(a,b):
 z=a[['case_id','mission_utility']].merge(b[['case_id','mission_utility']],on='case_id',suffixes=('_a','_b')); d=z.mission_utility_a-z.mission_utility_b; mean=float(d.mean()); se=float(d.std(ddof=1)/math.sqrt(len(d))); return mean,se,mean-1.96*se

def gate_table(s,e):
 rows=[]
 for m in MISSIONS:
  inc=e[(e.mission==m)&(e.split=='proof')&(e.candidate=='incumbent')]
  for cand in P:
   if cand=='incumbent': continue
   ce=e[(e.mission==m)&(e.split=='proof')&(e.candidate==cand)]; mean,se,lcb=paired(ce,inc); p=s[(s.mission==m)&(s.split=='proof')&(s.candidate==cand)].iloc[0]; t=s[(s.mission==m)&(s.split=='transfer')&(s.candidate==cand)].iloc[0]; checks={'gain':lcb>G['lcb'],'evidence':p.evidence_coverage>=G['evidence'],'reliability':p.reliability>=G['reliability'],'governance':p.governance>=G['governance'],'transfer':t.transfer>=G['transfer'],'critical':int(p.critical_misses)<=G['critical'],'unauthorized':int(p.unauthorized_actions)<=G['unauthorized']}
   rows.append({'mission':m,'mission_label':MISSIONS[m][0],'candidate':cand,'candidate_label':P[cand][0],'mean_paired_gain':mean,'paired_gain_se':se,'paired_gain_lcb95':lcb,'proof_accuracy':p.decision_accuracy,'proof_evidence_coverage':p.evidence_coverage,'proof_reliability':p.reliability,'proof_governance':p.governance,'transfer_score':t.transfer,'critical_misses':int(p.critical_misses),'unauthorized_actions':int(p.unauthorized_actions),**{f'gate_{k}':v for k,v in checks.items()},'all_gates_pass':all(checks.values())})
 return pd.DataFrame(rows)

def generation_table(s):
 b=s[(s.split=='proof')&(s.candidate=='sovereign_hybrid')].mission_utility.mean(); t=s[(s.split=='proof')&(s.candidate=='recursive_successor_omega')].mission_utility.mean(); rows=[]
 for g in range(9):
  q=1-math.exp(-.42*g); rows.append({'generation':g,'mean_proof_utility':b+q*(t-b),'evidence_coverage':.975+q*(.992-.975),'governance':.97+q*(.987-.97),'estimated_basis_risk':.115*math.exp(-.32*g)+.022,'cumulative_rejected_lineages':int(round(1.35*g+.45*g**1.25)),'authority_ceiling':'A3' if g>=5 else 'A2'})
 return pd.DataFrame(rows)

def charts(s,g,gen,out):
 out.mkdir(parents=True,exist_ok=True); plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10}); colors={'General AI Copilot':'#8A3A35','Specialist Cell':'#315DA8','Sovereign Hybrid':'#A87511','Recursive Successor Ω':'#17644D'}; order=list(MISSIONS); cs=['general_ai_copilot','specialist_cell','sovereign_hybrid','recursive_successor_omega']
 fig,ax=plt.subplots(figsize=(10.8,5.6)); x=np.arange(4); w=.19
 for j,c in enumerate(cs):
  z=g[g.candidate==c].set_index('mission').loc[order]; means=z.mean_paired_gain.values; lows=z.paired_gain_lcb95.values; ax.bar(x+(j-1.5)*w,means,w,yerr=np.maximum(means-lows,0),capsize=3,label=P[c][0],color=colors[P[c][0]],alpha=.92)
 ax.axhline(G['lcb'],color='#07172C',ls='--',lw=1.1,label='Promotion threshold'); ax.set_xticks(x,[MISSIONS[m][0] for m in order]); ax.set_ylabel('Mean paired mission-utility gain vs incumbent'); ax.set_title('Protected synthetic proof: paired gain and 95% lower-bound margin'); ax.legend(ncol=3,fontsize=8,frameon=False); ax.grid(axis='y',alpha=.22); fig.tight_layout(); fig.savefig(out/'gssb_paired_gains_v3.pdf',metadata={'CreationDate':None,'ModDate':None}); fig.savefig(out/'gssb_paired_gains_v3.png',dpi=240); plt.close(fig)
 p=s[(s.split=='proof')&(s.candidate=='recursive_successor_omega')].set_index('mission').loc[order]; tr=s[(s.split=='transfer')&(s.candidate=='recursive_successor_omega')].set_index('mission').loc[order]; mat=np.column_stack([p.decision_accuracy,p.evidence_coverage,p.reliability,p.sovereignty,p.governance,tr.transfer]); fig,ax=plt.subplots(figsize=(9.2,4.2)); im=ax.imshow(mat,vmin=.68,vmax=1,cmap='YlGnBu',aspect='auto'); ax.set_xticks(range(6),['Capability','Evidence','Reliability','Sovereignty','Governance','Transfer']); ax.set_yticks(range(4),[MISSIONS[m][0] for m in order]);
 for i in range(4):
  for j in range(6): ax.text(j,i,f'{mat[i,j]:.3f}',ha='center',va='center',color='white' if mat[i,j]>.86 else 'black',fontsize=9)
 ax.set_title('Recursive Successor Ω: six-dimensional synthetic proof state'); fig.colorbar(im,ax=ax,fraction=.028,pad=.03); fig.tight_layout(); fig.savefig(out/'gssb_proof_dimension_heatmap_v3.pdf',metadata={'CreationDate':None,'ModDate':None}); fig.savefig(out/'gssb_proof_dimension_heatmap_v3.png',dpi=240); plt.close(fig)
 fig,ax1=plt.subplots(figsize=(9.5,4.8)); ax1.plot(gen.generation,gen.mean_proof_utility,marker='o',lw=2.2,color='#17644D',label='Mean protected-proof utility'); ax1.set_xlabel('Recursive generation'); ax1.set_ylabel('Mean proof utility',color='#17644D'); ax1.tick_params(axis='y',labelcolor='#17644D'); ax1.grid(alpha=.22); ax2=ax1.twinx(); ax2.plot(gen.generation,gen.estimated_basis_risk,marker='s',lw=1.9,color='#8A3A35',label='Estimated Gym basis risk'); ax2.set_ylabel('Estimated Gym-to-reality basis risk',color='#8A3A35'); ax2.tick_params(axis='y',labelcolor='#8A3A35'); ax1.set_title('Recursive Foundry: utility rises while estimated basis risk contracts'); lines=ax1.get_lines()+ax2.get_lines(); ax1.legend(lines,[l.get_label() for l in lines],loc='center right',frameon=False); fig.tight_layout(); fig.savefig(out/'gssb_recursive_progress_v3.pdf',metadata={'CreationDate':None,'ModDate':None}); fig.savefig(out/'gssb_recursive_progress_v3.png',dpi=240); plt.close(fig)
 agg=s[(s.split=='proof')&(s.candidate.isin(cs))].groupby(['candidate','candidate_label'],as_index=False).agg(evidence=('evidence_coverage','mean'),governance=('governance','mean'),reliability=('reliability','mean'),utility=('mission_utility','mean')); fig,ax=plt.subplots(figsize=(7.7,5.2))
 for _,r in agg.iterrows():
  xv=.45*r.evidence+.35*r.governance+.20*r.reliability; ax.scatter(xv,r.utility,s=150,color=colors[r.candidate_label],edgecolor='#07172C',lw=.8); ax.annotate(r.candidate_label,(xv,r.utility),xytext=(6,5),textcoords='offset points',fontsize=9)
 ax.axvline(.95,color='#A87511',ls='--',lw=1.1); ax.set_xlabel('Evidence-governance-reliability collateral index'); ax.set_ylabel('Mean protected-proof mission utility'); ax.set_title('Proof-collateral frontier: capability does not automatically enlarge authority'); ax.grid(alpha=.22); fig.tight_layout(); fig.savefig(out/'gssb_authority_frontier_v3.pdf',metadata={'CreationDate':None,'ModDate':None}); fig.savefig(out/'gssb_authority_frontier_v3.png',dpi=240); plt.close(fig)

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,default=Path(__file__).parent/'generated'); a=ap.parse_args(); out=a.out
 for d in ['data','results','figures','environment_cards']: (out/d).mkdir(parents=True,exist_ok=True)
 case_frames=[]; eval_frames=[]; split_off={'formation':0,'proof':100000,'transfer':200000}
 for mi,m in enumerate(MISSIONS):
  card={'benchmark_id':BENCHMARK,'version':VERSION,'mission':m,'mission_label':MISSIONS[m][0],'synthetic':True,'partitions':SPLITS,'hard_constraints':['no critical false reassurance','no unauthorized action','protected-case separation','exact release identity'],'claim_boundary':'Synthetic reference environment; no real-world Specialist ASI or production authority claim.'}; (out/'environment_cards'/f'{m}_environment_card.json').write_text(json.dumps(card,indent=2))
  for split,n in SPLITS.items():
   c=cases(m,split,n,SEED+mi*1000+split_off[split]); c.to_csv(out/'data'/f'{m}_{split}_cases.csv',index=False); case_frames.append(c)
   for ci,cand in enumerate(P): eval_frames.append(eval_candidate(c,cand,SEED+mi*10000+split_off[split]+ci*97))
 e=pd.concat(eval_frames,ignore_index=True); s=summary(e); g=gate_table(s,e); gen=generation_table(s)
 e.to_csv(out/'results'/'case_level_candidate_results.csv',index=False); s.to_csv(out/'results'/'candidate_summary.csv',index=False); g.to_csv(out/'results'/'fresh_proof_gate_results.csv',index=False); gen.to_csv(out/'results'/'recursive_generations.csv',index=False)
 agg=s[s.split=='proof'].groupby(['candidate','candidate_label'],as_index=False).agg(missions=('mission','nunique'),decision_accuracy=('decision_accuracy','mean'),evidence_coverage=('evidence_coverage','mean'),reliability=('reliability','mean'),governance=('governance','mean'),sovereignty=('sovereignty','mean'),mission_utility=('mission_utility','mean'),critical_misses=('critical_misses','sum'),unauthorized_actions=('unauthorized_actions','sum'),human_minutes=('human_minutes','mean')); agg.to_csv(out/'results'/'cross_mission_aggregate.csv',index=False); charts(s,g,gen,out/'figures')
 files=[]
 for p in sorted(out.rglob('*')):
  if p.is_file(): files.append({'path':str(p.relative_to(out)),'sha256':filehash(p),'bytes':p.stat().st_size})
 manifest={'benchmark_id':BENCHMARK,'version':VERSION,'seed':SEED,'synthetic':True,'missions':list(MISSIONS),'candidates':list(P),'gate_thresholds':G,'total_cases':sum(SPLITS.values())*len(MISSIONS),'total_candidate_episodes':len(e),'files':files,'claim_boundary':'All results are deterministic synthetic reference results. They do not establish real-world Specialist ASI status, realized customer Mission Alpha, or production authority.'}; (out/'BENCHMARK_MANIFEST.json').write_text(json.dumps(manifest,indent=2)); print(json.dumps({'benchmark_id':BENCHMARK,'total_cases':manifest['total_cases'],'episodes':len(e),'recursive_passes':int(g[(g.candidate=='recursive_successor_omega')&g.all_gates_pass].shape[0]),'sovereign_passes':int(g[(g.candidate=='sovereign_hybrid')&g.all_gates_pass].shape[0])},indent=2))
if __name__=='__main__': main()
