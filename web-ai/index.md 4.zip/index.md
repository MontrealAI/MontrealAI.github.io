---
title: Montréal Artificial Intelligence
---
## WebAI — Artificial Intelligence for the Web

__Deploying machine learning in the browser unlocks new possibilities__, like interactive artificial intelligence! On a mobile device, the algorithm can even leverage sensor data (i.e.: gyroscope or accelerometer). Further, all data stays on the client, making TensorFlow.js useful for privacy preserving applications.

![Montréal.AI Web — Artificial Intelligence for the Web](../images/ai_web.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

## Three workflows with TensorFlow.js :

  * Existing, pre-trained model can be imported for inference ;

  * Imported model can re-trained quickly (transfer learning) with only a small amount of data ; and
  
  * Models can be directly authored (define, train, and run) in the browser.
  
There’s no need to install any libraries or drivers. Just open a webpage, and your program is ready to run. 

![An overview of TensorFlow.js APIs. TensorFlow.js is powered by WebGL and supports importing TensorFlow SavedModels and Keras models.](../images/TensorFlow_js_API.png "An overview of TensorFlow.js APIs.")

## How Can I Order an AI Agent ?

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
