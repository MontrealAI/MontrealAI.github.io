---
title: WebAI — Artificial Intelligence for the Web
---
## Deploying AI in the Browser

Running machine learning programs entirely client-side in the browser unlocks new opportunities, like interactive Artificial Intelligence (_to be continued..._)!

![Montréal.AI Web — Artificial Intelligence for the Web](../images/ai_web.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

## Low-Latency Inference and Privacy Preserving Applications

![An overview of TensorFlow.js](../images/TensorFlow_js_API.png "An overview of TensorFlow.js")

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
