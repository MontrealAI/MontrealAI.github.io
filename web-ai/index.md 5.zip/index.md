---
title: Montréal Artificial Intelligence
---
## WebAI — Artificial Intelligence for the Web

__Deploying machine learning in the browser unlocks new possibilities__, like interactive artificial intelligence! On a mobile device, the algorithm can even leverage sensor data (i.e.: gyroscope or accelerometer). Further, all data stays on the client, making TensorFlow.js useful for privacy preserving applications.

![Montréal.AI Web — Artificial Intelligence for the Web](../images/ai_web.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

## Three workflows with TensorFlow.js :

  * Existing, pre-trained model can be imported for inference ;

  * Imported model can re-trained quickly (transfer learning) with only a small amount of data ; and
  
  * Models can be directly authored (define, train, and run) in the browser.
  
There’s no need to install any libraries or drivers. Just open a webpage, and your program is ready to run. 

![An overview of TensorFlow.js APIs. TensorFlow.js is powered by WebGL and supports importing TensorFlow SavedModels and Keras models.](../images/TensorFlow_js_API.png "An overview of TensorFlow.js APIs.")

## How Can I Order an AI Agent ?

AI systems can achieve serious revenue. Montréal Artificial Intelligence develops machine learning agents in the browser that achieves goal-oriented behavior up to fully-fledged AI system

<p data-height="655" data-theme-id="0" data-slug-hash="XBzedV" data-default-tab="js,result" data-user="QuebecAI" data-pen-title="Neuro-evolution with TensorFlow.js" class="codepen">See the Pen <a href="https://codepen.io/QuebecAI/pen/XBzedV/">Neuro-evolution with TensorFlow.js</a> by QuebecAI (<a href="https://codepen.io/QuebecAI">@QuebecAI</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

✉️ __Email Us__ : info@montreal.ai
🌐 __Website__ : http://www.montreal.ai/

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
