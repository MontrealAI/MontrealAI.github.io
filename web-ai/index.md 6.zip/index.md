---
title: Montréal Artificial Intelligence
---
## WebAI — Artificial Intelligence for the Web

__Deploying machine learning in the browser unlocks new possibilities__, like interactive artificial intelligence! On a mobile device, the algorithm can even leverage sensor data (i.e.: gyroscope or accelerometer). Further, all data stays on the client, making TensorFlow.js useful for privacy preserving applications.

![Montréal.AI Web — Artificial Intelligence for the Web](../images/ai_web.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

> " _Artificial Intelligence is about recognising patterns, Artificial Life is about creating patterns._ "
<p align="right">— Mizuki Oka et al, #alife2018</p>

## Three workflows with TensorFlow.js :

  * Existing, pre-trained model can be imported for inference ;

  * Imported model can re-trained quickly (transfer learning) with only a small amount of data ; and
  
  * Models can be directly authored (define, train, and run) in the browser.
  
There’s no need to install any libraries or drivers. Just open a webpage, and your AI Agent is ready to run. 

![An overview of TensorFlow.js APIs. TensorFlow.js is powered by WebGL and supports importing TensorFlow SavedModels and Keras models.](../images/TensorFlow_js_API.png "An overview of TensorFlow.js APIs.")

## Transform your Web Site with an AI Agent

__Fully-fledged AI systems can achieve serious revenue!__ 

Montréal Artificial Intelligence helps to transform Web sites for the age of artificial intelligence by developing machine learning agents in the browser that achieves goal-oriented behavior.

Demos : 

  1. __*Solving the cart-pole control problem in the browser using the policy-gradient method*__

  * Live demo : https://storage.googleapis.com/tfjs-examples/cart-pole/dist/index.html
  * Code : https://github.com/tensorflow/tfjs-examples/tree/master/cart-pole

  2. __*Predicting balls and strikes using TensorFlow.js*__
<p align="center">
![Montréal.AI Web — Artificial Intelligence for the Web](../images/PredictingBallsStrikes.gif "Montréal.AI Web : Deploying Machine Learning Models in the Browser")
</p>
  * Blog : https://medium.com/tensorflow/predicting-balls-and-strikes-using-tensorflow-js-2acf1d7a447c

  3. __*L1: Tensor Studio — An in-browser live-programming environment by Milan Lajtoš*__

![Montréal.AI Web — Artificial Intelligence for the Web](../images/L1TensorStudio.png "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

  * Live demo : https://mlajtos.github.io/L1/latest/ 
  * Github : https://github.com/mlajtos/L1

  4. __*Move Mirror: An AI Experiment with Pose Estimation in the Browser using TensorFlow.js*__
<p align="center">
![Montréal.AI Web — Artificial Intelligence for the Web](../images/MoveMirror.gif "Montréal.AI Web : Deploying Machine Learning Models in the Browser")
</p>
  * By Jane Friedhoff and Irene Alvarado : https://medium.com/tensorflow/move-mirror-an-ai-experiment-with-pose-estimation-in-the-browser-using-tensorflow-js-2f7b769f9b23

  5. __*Animation with CPPNs and TensorFlow.js, an @observablehq notebook by Emily Reif*__

* @observablehq notebook by Emily Reif : https://beta.observablehq.com/@emilyreif/animation-with-cppns

<p data-height="655" data-theme-id="0" data-slug-hash="XBzedV" data-default-tab="js,result" data-user="QuebecAI" data-pen-title="Neuro-evolution with TensorFlow.js" class="codepen">See the Pen <a href="https://codepen.io/QuebecAI/pen/XBzedV/">Neuro-evolution with TensorFlow.js</a> by QuebecAI (<a href="https://codepen.io/QuebecAI">@QuebecAI</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

__References__ :

  * '*Introducing TensorFlow.js: Machine Learning in Javascript*' - https://medium.com/tensorflow/introducing-tensorflow-js-machine-learning-in-javascript-bf3eab376db

To order your AI Agent :

✉️ __Email Us__ : info@montreal.ai
🌐 __Website__ : http://www.montreal.ai/

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
