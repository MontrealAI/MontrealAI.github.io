---
title: Montréal Artificial Intelligence
---
## Montréal.AI Academy : AI 101

__AI 101 : The Dawn of Artificial Intelligence__

[![AI 101 : The First Comprehensive Overview of AI for the General Public](../images/academy1920cover_v0.jpg "AI 101 : The First Comprehensive Overview of AI for the General Public")](http://montreal.ai/academy.pdf)

## The First Comprehensive Overview of AI for the General Public

__AI 101 : A Well-Crafted Actionable 75 Minutes Tutorial__

{% blockquote Andrew Ng https://www.quora.com/I-want-to-pursue-machine-learning-as-a-career-but-not-sure-if-I-am-qualified-How-can-I-test-myself/answer/Andrew-Ng?share=f3fad17c&srid=tpaQ I want to pursue machine learning as a career but not sure if I am qualified... %}
You are qualified for a career in machine learning!
{% endblockquote %}

POWERFUL & USEFUL. This actionable tutorial is designed to entrust everybody with the mindset, the skills and the tools to see artificial intelligence from an empowering new vantage point by :

— Exalting state of the art discoveries and science ;
— Curating the best open-source codes & implementations ; and
— Embodying the impetus that drives today’s artificial intelligence.

Montréal.AI is the largest artificial intelligence community in Canada. **_Join us and learn_** at https://www.facebook.com/groups/MontrealAI/ !

## #AI4Artists : Unveilling a World of Hidden Secrets

__Pioneering Legendary Creations__

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Vincent Boucher, B. Sc. Theoretical Physics, M. A. Government Policy Analysis and M. Sc. Aerospace Engineering

Designed for artists, _#AI4Artists_ is created to inspire artists who, with AI, will shape the 21st Century.

[![AI4Artists : The First Comprehensive Overview of All (全) AI for Artists](../images/AI4ArtistsProgram_v4.jpg "AI4Artists : The First Comprehensive Overview of All (全) AI for Artists")](http://www.montreal.ai/AI4Artists.pdf)

## Getting Started : Readings, Source Code and Science

If you are a newcomer to artificial intelligence, here are some ressources to get started now :

#### Coding
- [Learn X in Y minutes (Where X=python3)](https://learnxinyminutes.com/docs/python3/) — Louie Dinh
- [Python Numpy Tutorial](http://cs231n.github.io/python-numpy-tutorial/) — Justin Johnson
- [A Neural Network in 11 lines of Python](http://iamtrask.github.io/2015/07/12/basic-python-network/) — iamtrask
- [The WIRED Guide to artificial intelligence](https://www.wired.com/story/guide-artificial-intelligence/) — WIRED
- [Neural Network Playground](http://playground.tensorflow.org/) — TensorFlow
- [TensorFlow Blog](https://medium.com/tensorflow) — TensorFlow
- [JupyterLab is Ready for Users](https://blog.jupyter.org/jupyterlab-is-ready-for-users-5a6f039b8906) — Project Jupyter
- [Practical Deep Learning For Coders](http://course.fast.ai) — Jeremy Howard, Rachel Thomas | Fast.AI
- [Deep Learning](https://www.udacity.com/course/deep-learning--ud730) — Vincent Vanhoucke | Google
- [Introducing TensorFlow.js: Machine Learning in Javascript](https://medium.com/tensorflow/introducing-tensorflow-js-machine-learning-in-javascript-bf3eab376db) —  Josh Gordon, Sara Robinson

#### Readings and Science
- [Deep Learning](https://www.cs.toronto.edu/~hinton/absps/NatureDeepReview.pdf) — Yann LeCun, Yoshua Bengio, Geoffrey Hinton
- [Clear Explanations of Machine Learning](https://distill.pub) — Distill
- [The Matrix Calculus You Need For Deep Learning](http://parrt.cs.usfca.edu/doc/matrix-calculus/index.html) — Terence Parr, Jeremy Howard
- [Neural Networks and Deep Learning](http://neuralnetworksanddeeplearning.com) — Michael Nielsen 
- [Deep Learning Book](http://www.deeplearningbook.org) — Ian Goodfellow, Yoshua Bengio, Aaron Courville
- [Competitive Programmer’s Handbook](https://cses.fi/book/book.pdf) — Antti Laaksonen
- [A Visual Guide to Evolution Strategies](http://blog.otoro.net/2017/10/29/visual-evolution-strategies/) — David Ha
- [Deep RL Bootcamp](https://sites.google.com/view/deep-rl-bootcamp/lectures) — Pieter Abbeel, Yan (Rocky) Duan, Xi (Peter) Chen, Andrej Karpathy
- [Reinforcement Learning: An Introduction](https://drive.google.com/file/d/1xeUDVGWGUUv1-ccUMAZHJLej2C7aAFWY/view) — Andrew Barto and Richard S. Sutton
- [Over 200 of the Best Machine Learning, NLP, and Python Tutorials — 2018 Edition](https://medium.com/machine-learning-in-practice/over-200-of-the-best-machine-learning-nlp-and-python-tutorials-2018-edition-dd8cf53cb7dc) — Robbie Allen
- [Deep Learning Papers Reading Roadmap](https://github.com/floodsung/Deep-Learning-Papers-Reading-Roadmap) — Flood Sung
- [World Models](https://worldmodels.github.io) — David Ha, Jürgen Schmidhuber
- [Constructing exact representations of quantum many-body systems with deep neural networks](https://arxiv.org/pdf/1802.09558.pdf) — Giuseppe Carleo

> "**_Give me a two-layer DBM and I can move the (quantum) world._**" — Giuseppe Carleo

#### General Ressources

- [GitXiv | arXiv + CODE](http://www.gitxiv.com) — Collaborative Open Computer Science
- [The Malicious Use of Artificial Intelligence: Forecasting, Prevention, and Mitigation](https://arxiv.org/pdf/1802.07228.pdf) — Miles Brundage, Shahar Avin, Jack Clark, Helen Toner, Peter Eckersley, Ben Garfinkel, Allan Dafoe, Paul Scharre, Thomas Zeitzoff, Bobby Filar, Hyrum Anderson, Heather Roff, Gregory C. Allen, Jacob Steinhardt, Carrick Flynn, Seán Ó hÉigeartaigh, Simon Beard, Haydn Belfield, Sebastian Farquhar, Clare Lyle, Rebecca Crootof, Owain Evans, Michael Page, Joanna Bryson, Roman Yampolskiy, Dario Amodei
- [The Best Textbooks on Every Subject](https://www.lesswrong.com/posts/xg3hXCYQPJkwHyik2/the-best-textbooks-on-every-subject) — lukeprog

<p data-height="265" data-theme-id="0" data-slug-hash="WgwbBJ" data-default-tab="js,result" data-user="QuebecAI" data-pen-title="Montreal.AI's Bubble Bath" class="codepen">See the Pen <a href="https://codepen.io/QuebecAI/pen/WgwbBJ/">Montreal.AI's Bubble Bath</a> by QuebecAI (forked from Tero Parviainen) (<a href="https://codepen.io/QuebecAI">@QuebecAI</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

###### ＊ _This 75 minutes tutorial is presently in alpha, with a limited number of  customers to help us refine it. As we enter beta, we'll take on many more groups (minimum 150 persons) from the waiting list._

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*

#__AIFirst__ #__MontrealAI__ #__MontrealAIAcademy__ #__MontrealArtificialIntelligence__
