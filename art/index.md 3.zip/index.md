---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## MONTRÉAL.AI FINE ARTS

__Creating Fine AI Arts History | Quintessential Launches in Major Cities!__

*Quebec, Montreal, Vancouver, San Maarten, Beverly Hills, Caesar’s, Panama, Brasil, Paris, Milano, Principauté de Monaco, Geneva, Belgium, Germany, Luxembourg, Spain, Austria, London, Russian Federation, Aspen, Maui, SoHo, Israel, La Jolla, Macau, Dubai, India, Qatar, Saudi Arabia, Beijing, Shanghai, Hong Kong, Tokyo Midtown and Tapei.*

__Pioneering Legendary Fine AI Arts — Montréal.AI is Presenting a New World Age of Artistic Visions.__

<p align="center">
![The Scent of AI (Perfume) — Signed: Montreal.AI](../images/26eb011ai-v0.jpg "The Scent of AI (Perfume) — Signed: Montreal.AI")
</p>

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Montréal.AI Fine Arts

__Montréal.AI Fine Arts__ reflects the aesthetic diversity, conceptual richness and ‘purist’ form of AI creativity expressed by the machine. It is a blending of Art, Culture, and Science in the spirit of Leonardo da Vinci.

Opening the doors to the AI art movement of the 21st Century and created for the true connoisseurs who define the trends, __Montréal.AI Fine Arts__ is causing a huge stir amongst top art collectors and the most brilliant, influential, and iconoclastic figures worldwide and is regarded as the highest in the hierarchy of genres.

Captivating a discerning audience, __Montréal.AI Fine Arts__ is preparing a worldwide PR campaing with major talk show appearances, a feature film and a TV documentary. *We are looking for Ambassadors & Partners.*

__❖ Commissioned AI Fine Arts (Superhuman Luxury)__
During the Renaissance, Pope Julius II commissioned painter Michelangelo for artwork of the Sistine Chapel ceiling at the Vatican. Today, high net worth corporations, successful financiers and world's premier luxury houses may commission AI artwork from Montréal.AI Fine Arts. Signed: Montreal.AI

## A New Day Has Come in Art Industry

__Art-Market History__

![Edmond de Belamy, from La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, from La Famille de Belamy")

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [A sign of things to come? AI-produced artwork sells for $433K, smashing expectations](https://edition.cnn.com/style/article/obvious-ai-art-christies-auction-smart-creativity/index.html) — Allyssia Alleyne, CNN
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

> "**_A spokesperson from Christie's told us of the market's excitement as this significant shift. "We can confirm there were 5 different bidders from all parts of the world competing for this lot at that high price level, which seems a good indication of collector interest and future market potential for AI art generally..."_**" — Adam Heardman, MutualArt

## Defining the Genre of AI-Made Fine Art

__A Deep Understanding of the World, People and Human Nature.__

![Principia of The Grand Design: Montréal.AI Fine Arts believes in seamlessly seing relationships that matter](../images/ExTradingUniverseTwoMay18HD1080-v0.mp4 "Principia of The Grand Design: Montréal.AI Fine Arts believes in seamlessly seing relationships that matter")

> "**_To identify truly path-breaking work, we would do better to stop asking where the boundary line lies between human artists’ agency and that of AI toolsets, and instead start asking whether human artists are using AI to plumb greater conceptual and aesthetic depths than researchers or coders._**" — Tim Schneider and Naomi Rea, artnet, September 25, 2018

__Deep Learning + Deep Reinforcement Learning + Generative Adversarial Nets + Meta-Learning + Self-Play__

### References

- [Data Science, Machine Learning and Artificial Intelligence for Art](https://towardsdatascience.com/data-science-machine-learning-and-artificial-intelligence-for-art-1ac48c4fad41) — Vishal Kumar
- [Scaling the Mission: The Met Collection API (406,000 images of over 205,000 CC0 objects)](https://www.metmuseum.org/blogs/now-at-the-met/2018/met-collection-api) — Loic Tallon, Chief Digital Officer
- [What do 50 million drawings look like?](https://quickdraw.withgoogle.com/data) — Google
- [Neural scene rendering: Transfer learning to render a fruit still life from photos](https://docs.google.com/presentation/d/182KZT1Qg1rY8qnroDytn-4z5ODFjNSYkfNlwbDJAI-o/edit#slide=id.g35f391192_00) — Brett Göhre
- GAN Lab: Play with Generative Adversarial Networks (GANs) in your browser! [Web](https://poloclub.github.io/ganlab/) | [Paper](https://minsuk.com/research/papers/kahng-ganlab-vast2018.pdf) — Minsuk Kahng, Nikhil Thorat, Polo Chau, Fernanda Viégas, and Martin Wattenberg
- [Generating Memoji from Photos](https://patniemeyer.github.io/2018/10/29/generating-memoji-from-photos.html) — Pat Niemeyer
- [Playing a game of GANstruction](https://thegradient.pub/playing-a-game-of-ganstruction/) — Helena Sarin
- [TensorFlow-GAN (TFGAN)](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/contrib/gan) — Joel Shor, Sergio Guadarrama
- [Progressive GANs | Notebook with smooth interpolations through z-space](https://github.com/genekogan/progressive_growing_of_gans/blob/master/generate.ipynb) — Gene Kogan
- Self-Attention GAN [Paper](https://arxiv.org/abs/1805.08318) | [Tensorflow implementation](https://github.com/brain-research/self-attention-gan) — Han Zhang, Ian Goodfellow, Dimitris Metaxas, Augustus Odena
- [Discriminator Rejection Sampling](https://arxiv.org/abs/1810.06758) — Samaneh Azadi, Catherine Olsson, Trevor Darrell, Ian Goodfellow, Augustus Odena
- [Tensorpack | Generative Adversarial Networks](https://github.com/tensorpack/tensorpack/tree/master/examples/GAN) — Tensorpack
- [Ngx | Neural network based visual generator and mixer](https://github.com/keijiro/Ngx) — Keijiro Takahashi
- [A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf) — Colin Raffel
- [Deep Variational Reinforcement Learning for POMDPs](https://arxiv.org/abs/1806.02426) — Maximilian Igl, Luisa Zintgraf, Tuan Anh Le, Frank Wood, Shimon Whiteson
- [Learning Dexterity](https://blog.openai.com/learning-dexterity/) — OpenAI
- [Robots that Learn](https://blog.openai.com/robots-that-learn/) — OpenAI
- [(Self-Play) | OpenAI Five](https://blog.openai.com/openai-five/) — OpenAI
- [TFHub state-of-the-art AutoAugment Modules](https://tfhub.dev/s) — TensorFlow
- [Creatability: a new collection of experiments exploring ways to make creative tools more accessible](https://g.co/creatability) — Experiments with Google
- [Evolved Virtual Creatures, Evolution Simulation, 1994](https://youtu.be/JBgG_VSP7f8) — Karl Sims
- Reinforcement Learning for Improving Agent Design: What happens when we let an agent learn a better body design together with learning its task? [Article](https://designrl.github.io/) | [Paper](https://arxiv.org/abs/1810.03779 ) — David Ha

> "**_The defining art-making technology of our era will be AI._**" — Rama Allen

## The House of Montréal.AI Fine Arts

__Fine AI Arts History & Heritage: The Building of a Legacy__

__*Montréal.AI Fine Arts*__ is ahead of a trend that will profoundly impact the $350 billion / Year international fashion, fine arts & jewelry industry ( 🌐 http://www.billionaire.tv/TheGazette.pdf ).

Our fine AI art creations are pure object of désirs, fairytale lands and enchanted dreams conveying a feeling of exclusiveness : A fascinating, provocative and vibrant AI poetry.

![A Renewal of the High Renaissance Ideals](../images/h355ai1440.jpg "A Renewal of the High Renaissance Ideals")

Neural networks, code, algorithms, generative models (GANs), aesthetic theory: A Renewal of the High Renaissance Ideals.

AI-generated | We're developing a Superhuman RL Agent via Self-Play to create revolutionary designs... and unveils a majestic world of hidden secrets.

Numbered and Signed Original Print Including Certificate of Authenticity

__❖ The Scent of AI (Perfume)__
Signed: Montreal.AI
 


__❖ Collection of Lullabies (Book)__
Leather-bound numbered, signed and lettered object of desire.

__❖ Many-Worlds Jewelry ( 💎 )__
A revolutionary line exalting the purest superhuman jewellery designs on a truly global scale. A line as enchanting as the muses it inspires, for the Fashionees who will define the trends of our era. Signed: Montreal.AI

### A Legendary History: The Source of an Exceptional Legacy

__The General Secretariat of the Montréal.AI Fine Arts Executive Council__

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/TheGazetteBusinessFrontPage.tif "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

A professional skilled catalyst versed in innovative research, high financial engineering and international luxury scene, Montreal.AI's Founding Chairman Vincent Boucher received, on the 15th of October 2009, the prestigious __Guinness World Records__ title for his Largest Cut Paraiba Tourmaline.

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

> "**_Financier (Vincent Boucher) acquires world’s rarest stone."_**" — Mike King, The Gazette

## #AI4Artists : Unveilling a World of Hidden Secrets ＊

__Pioneering Legendary Creations : 75 Minutes Tutorial__

[![Pioneering Legendary Creations : 75 Minutes Tutorial](../images/AI4ArtistsP1.jpg "#AI4Artists : Unveilling a World of Hidden Secrets")](http://www.montreal.ai/AI4Artists.pdf)

Designed for artists, [_#AI4Artists_](http://www.montreal.ai/AI4Artists.pdf) is created to inspire artists who, with AI, will shape the 21st Century.

<p data-height="265" data-theme-id="0" data-slug-hash="WgwbBJ" data-default-tab="js,result" data-user="QuebecAI" data-pen-title="Montreal.AI's Bubble Bath" class="codepen">See the Pen <a href="https://codepen.io/QuebecAI/pen/WgwbBJ/">Montreal.AI's Bubble Bath</a> by QuebecAI (forked from Tero Parviainen) (<a href="https://codepen.io/QuebecAI">@QuebecAI</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

###### ＊ _This 75 minutes tutorial is presently in alpha, with a limited number of  customers to help us refine it. As we enter beta, we'll take on many more groups (minimum 150 persons) from the waiting list._

## A Truly Special Celebration that is Certain to Make History!

[![Our Vision : To be the keystone of the AI Space industry.](../images/ManyWorldsJewelry-v8.jpg "Our Vision : To be the keystone of the AI Space industry.")](http://www.montreal.ai/mtl.pdf)

For Andre Breton, the father of surrealism, the purpose of Art is the unification of the real and the imaginary. __Montréal.AI Fine Arts__ makes Breton’s dream come true. A truly special celebration in the world of fine arts, fashion and high jewelry and one that is certain to make history!

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Executive Council and Administrative Head Office*

#__AIFirst__ #__MontrealAI__ #__MontrealAISpace__ #__MontrealArtificialIntelligence__
